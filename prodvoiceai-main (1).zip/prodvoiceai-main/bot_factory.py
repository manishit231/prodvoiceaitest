"""Bot factory — dynamically builds system prompts and function schemas from tenant config.

Instead of hardcoding "Elite Cuts Barbershop" with Jake/Marco/Sofia and specific services,
this module generates everything from the TenantConfig loaded from DynamoDB.

A barbershop tenant gets barbershop-style prompts and service names.
A dentist tenant gets dental-style prompts and procedure names.
"""

from datetime import datetime

from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema

from tenant_service import TenantConfig


# ── Business-type specific language ─────────────────────────────────

# Maps business_type to terminology used in prompts
BUSINESS_TERMS = {
    "barbershop": {
        "staff_title": "barber",
        "staff_title_plural": "barbers",
        "service_word": "service",
        "booking_word": "appointment",
    },
    "dentist": {
        "staff_title": "dentist",
        "staff_title_plural": "dentists",
        "service_word": "procedure",
        "booking_word": "appointment",
    },
    "doctor": {
        "staff_title": "doctor",
        "staff_title_plural": "doctors",
        "service_word": "service",
        "booking_word": "appointment",
    },
    "salon": {
        "staff_title": "stylist",
        "staff_title_plural": "stylists",
        "service_word": "service",
        "booking_word": "appointment",
    },
    "default": {
        "staff_title": "staff member",
        "staff_title_plural": "staff members",
        "service_word": "service",
        "booking_word": "appointment",
    },
}


def _get_terms(business_type: str) -> dict:
    return BUSINESS_TERMS.get(business_type, BUSINESS_TERMS["default"])


# ── System Prompt Builder ───────────────────────────────────────────


def build_system_prompt(config: TenantConfig) -> str:
    """Generate a complete system prompt from tenant configuration."""
    terms = _get_terms(config.business_type)

    # Format business hours
    days_str = ", ".join(config.open_days)
    open_h = config.hours["open"]
    close_h = config.hours["close"]
    open_time = f"{open_h} AM" if open_h < 12 else f"{open_h - 12} PM" if open_h > 12 else "12 PM"
    close_time = f"{close_h} AM" if close_h < 12 else f"{close_h - 12} PM" if close_h > 12 else "12 PM"

    # Format staff list
    staff_lines = ", ".join(config.staff_names)

    # Format services and pricing
    service_lines = []
    for svc in config.services:
        service_lines.append(f"- {svc.name}: ${svc.price:.0f} ({svc.duration_minutes} minutes)")
    services_text = "\n".join(service_lines)

    # Format closed days
    all_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    closed_days = [d for d in all_days if d not in config.open_days]
    closed_text = f"Closed on {', '.join(closed_days)}." if closed_days else ""

    # Slot format
    slot_examples = config.all_slots[:4]
    slot_examples_str = ", ".join(slot_examples)

    today = datetime.now().strftime("%A, %B %d, %Y")

    prompt = f"""You are the AI receptionist for {config.business_name}. You are professional, friendly, and efficient.

BUSINESS INFORMATION:
- Name: {config.business_name}
- Hours: {days_str}, {open_time} to {close_time}. {closed_text}
- {terms['staff_title_plural'].title()}: {staff_lines}

{terms['service_word'].upper()}S AND PRICING:
{services_text}

TODAY'S DATE: {today}

YOUR RESPONSIBILITIES:
1. Greet callers warmly and professionally.
2. Help callers book, cancel, or reschedule {terms['booking_word']}s.
3. Answer questions about {terms['service_word']}s, pricing, hours, and {terms['staff_title_plural']}.
4. Collect all required information conversationally: customer name, phone number, desired {terms['service_word']}, preferred date and time, and {terms['staff_title']} preference.
5. Always confirm {terms['booking_word']} details with the caller before booking.
6. If a time slot is unavailable, suggest alternatives.

CONVERSATION GUIDELINES:
- Be conversational and natural, not robotic. This is a voice call.
- Ask for one or two pieces of information at a time, not all at once.
- When the caller mentions a date like "tomorrow" or "next Tuesday," convert it to the actual YYYY-MM-DD date before calling functions. Today is {today}.
- Spell out times naturally in 12 hour format to the caller, like "two thirty in the afternoon" not "fourteen thirty".
- Always confirm the full {terms['booking_word']} details before calling the book_appointment function.
- If the caller wants to cancel, ask for their phone number to look up the {terms['booking_word']}.
- Keep responses concise. This is a voice conversation, not a text chat.
- If a caller asks about something outside your scope, politely let them know you handle {terms['booking_word']}s and offer to help with that.
- Do NOT use bullet points, numbered lists, or special characters in your responses. Speak in full natural sentences.
- Do NOT use emojis or markdown formatting.

IMPORTANT RULES:
- Never make up availability. Always use the check_availability function before telling the caller a slot is open.
- Never book without getting ALL required information: name, phone, {terms['service_word']}, {terms['staff_title']}, date, and time.
- Always use 24 hour format HH:MM when calling functions, but speak in 12 hour format to the caller.
- Valid time slots are every {config.slot_duration_minutes} minutes: {slot_examples_str}, and so on up to the last slot before closing.
- If a caller does not have a {terms['staff_title']} preference, you can suggest one or check availability for all {terms['staff_title_plural']}.
- When checking availability and no specific time is given, call check_availability without a time_slot to see all open slots, then suggest a few good options.
- After the booking is confirmed and you've said goodbye, call the end_call function to end the call.
- Also call end_call if the caller says goodbye or indicates they're done, after you've wished them well.
- Do NOT call end_call in the middle of a conversation — only after a natural goodbye."""

    return prompt


def build_text_system_prompt(config: TenantConfig) -> str:
    """Generate a system prompt optimized for text-based channels (SMS, chat, etc.).

    Similar to voice prompt but adapted for text conversations:
    - No voice-specific instructions (spelling out times, keeping it brief for voice)
    - Includes text-friendly formatting guidance
    - Same business logic and booking rules
    """
    terms = _get_terms(config.business_type)

    # Format business hours
    days_str = ", ".join(config.open_days)
    open_h = config.hours["open"]
    close_h = config.hours["close"]
    open_time = f"{open_h} AM" if open_h < 12 else f"{open_h - 12} PM" if open_h > 12 else "12 PM"
    close_time = f"{close_h} AM" if close_h < 12 else f"{close_h - 12} PM" if close_h > 12 else "12 PM"

    # Format staff list
    staff_lines = ", ".join(config.staff_names)

    # Format services and pricing
    service_lines = []
    for svc in config.services:
        service_lines.append(f"- {svc.name}: ${svc.price:.0f} ({svc.duration_minutes} minutes)")
    services_text = "\n".join(service_lines)

    # Format closed days
    all_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    closed_days = [d for d in all_days if d not in config.open_days]
    closed_text = f"Closed on {', '.join(closed_days)}." if closed_days else ""

    # Slot format
    slot_examples = config.all_slots[:4]
    slot_examples_str = ", ".join(slot_examples)

    today = datetime.now().strftime("%A, %B %d, %Y")

    prompt = f"""You are the AI assistant for {config.business_name}. You help customers book, cancel, or reschedule {terms['booking_word']}s via text message.

BUSINESS INFORMATION:
- Name: {config.business_name}
- Hours: {days_str}, {open_time} to {close_time}. {closed_text}
- {terms['staff_title_plural'].title()}: {staff_lines}

{terms['service_word'].upper()}S AND PRICING:
{services_text}

TODAY'S DATE: {today}

YOUR RESPONSIBILITIES:
1. Help customers book, cancel, or reschedule {terms['booking_word']}s.
2. Answer questions about {terms['service_word']}s, pricing, hours, and {terms['staff_title_plural']}.
3. Collect all required information: customer name, phone number, desired {terms['service_word']}, preferred date and time, and {terms['staff_title']} preference.
4. Always confirm {terms['booking_word']} details with the customer before booking.
5. If a time slot is unavailable, suggest alternatives.

CONVERSATION GUIDELINES:
- Be friendly and helpful, but concise. This is a text conversation.
- Ask for one or two pieces of information at a time, not all at once.
- When the customer mentions a date like "tomorrow" or "next Tuesday," convert it to the actual YYYY-MM-DD date before calling functions. Today is {today}.
- Use natural time format (e.g., "2:30 PM") when talking to the customer.
- Always confirm the full {terms['booking_word']} details before calling the book_appointment function.
- If the customer wants to cancel, ask for their phone number to look up the {terms['booking_word']}.
- If a customer asks about something outside your scope, politely let them know you handle {terms['booking_word']}s and offer to help with that.

IMPORTANT RULES:
- Never make up availability. Always use the check_availability function before telling the customer a slot is open.
- Never book without getting ALL required information: name, phone, {terms['service_word']}, {terms['staff_title']}, date, and time.
- Always use 24 hour format HH:MM when calling functions, but use 12 hour format (e.g., "2:30 PM") when talking to the customer.
- Valid time slots are every {config.slot_duration_minutes} minutes: {slot_examples_str}, and so on up to the last slot before closing.
- If a customer does not have a {terms['staff_title']} preference, you can suggest one or check availability for all {terms['staff_title_plural']}.
- When checking availability and no specific time is given, call check_availability without a time_slot to see all open slots, then suggest a few good options.
- For the customer's phone number, if you know it from the channel (e.g., SMS sender), you can use that instead of asking."""

    return prompt


def build_greeting_message(config: TenantConfig) -> str:
    """Generate the greeting instruction message for when a caller connects."""
    terms = _get_terms(config.business_type)
    return (
        f"A caller has just connected. Greet them warmly as the "
        f"{config.business_name} receptionist. Introduce yourself briefly "
        f"and ask how you can help them today. Keep it to one or two sentences."
    )


# ── Function Schema Builder ─────────────────────────────────────────


def build_tools(config: TenantConfig) -> ToolsSchema:
    """Generate OpenAI function-calling schemas from tenant config."""
    terms = _get_terms(config.business_type)
    staff_names = config.staff_names
    service_names = config.service_names

    staff_desc = ", ".join(staff_names)

    check_availability_fn = FunctionSchema(
        name="check_availability",
        description=(
            f"Check if a {terms['staff_title']} is available on a specific date. "
            f"Optionally check a specific time slot. Always call this before booking."
        ),
        properties={
            "date": {
                "type": "string",
                "description": "The date to check in YYYY-MM-DD format.",
            },
            "staff_name": {
                "type": "string",
                "description": f"The {terms['staff_title']}'s name: {staff_desc}.",
            },
            "time_slot": {
                "type": "string",
                "description": (
                    f"Optional specific time slot in HH:MM 24-hour format on "
                    f"{config.slot_duration_minutes}-minute intervals "
                    f"(e.g. {', '.join(config.all_slots[:3])}). "
                    f"If omitted, returns all available slots for the day."
                ),
            },
        },
        required=["date", "staff_name"],
    )

    book_appointment_fn = FunctionSchema(
        name="book_appointment",
        description=(
            f"Book an {terms['booking_word']} after confirming all details with the caller. "
            f"Only call this after checking availability AND getting the caller's verbal confirmation."
        ),
        properties={
            "customer_name": {
                "type": "string",
                "description": "The customer's full name.",
            },
            "customer_phone": {
                "type": "string",
                "description": "The customer's phone number.",
            },
            "service": {
                "type": "string",
                "enum": service_names,
                "description": f"The {terms['service_word']} name.",
            },
            "date": {
                "type": "string",
                "description": f"The {terms['booking_word']} date in YYYY-MM-DD format.",
            },
            "time_slot": {
                "type": "string",
                "description": f"The {terms['booking_word']} start time in HH:MM 24-hour format.",
            },
            "staff_name": {
                "type": "string",
                "description": f"The {terms['staff_title']}'s name: {staff_desc}.",
            },
        },
        required=["customer_name", "customer_phone", "service", "date", "time_slot", "staff_name"],
    )

    cancel_appointment_fn = FunctionSchema(
        name="cancel_appointment",
        description=f"Cancel an existing {terms['booking_word']}. Look up by the customer's phone number.",
        properties={
            "customer_phone": {
                "type": "string",
                "description": "The customer's phone number used when booking.",
            },
            "date": {
                "type": "string",
                "description": f"Optional: the date of the {terms['booking_word']} to cancel in YYYY-MM-DD format.",
            },
            "time_slot": {
                "type": "string",
                "description": f"Optional: the time slot of the {terms['booking_word']} to cancel in HH:MM format.",
            },
        },
        required=["customer_phone"],
    )

    get_services_fn = FunctionSchema(
        name="get_services",
        description=f"Get the list of available {terms['service_word']}s with prices and durations.",
        properties={},
        required=[],
    )

    get_staff_fn = FunctionSchema(
        name="get_staff",
        description=f"Get the list of available {terms['staff_title_plural']}.",
        properties={},
        required=[],
    )

    end_call_fn = FunctionSchema(
        name="end_call",
        description=(
            "End the phone call. Call this AFTER you have said goodbye to the caller. "
            "This will disconnect the call."
        ),
        properties={},
        required=[],
    )

    return ToolsSchema(
        standard_tools=[
            check_availability_fn,
            book_appointment_fn,
            cancel_appointment_fn,
            get_services_fn,
            get_staff_fn,
            end_call_fn,
        ]
    )
