"""Tenant onboarding script — seed a new business customer into DynamoDB.

Usage:
    # Seed the demo barbershop:
    uv run seed_tenant.py --demo barbershop

    # Seed the demo dentist:
    uv run seed_tenant.py --demo dentist

    # Seed a custom tenant:
    uv run seed_tenant.py \
        --id t_003 \
        --name "Sunrise Salon" \
        --type salon \
        --phone +15551234567 \
        --hours '{"open": 9, "close": 18, "days": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]}' \
        --staff "Emma:Lead Stylist,Lily:Junior Stylist" \
        --services "Haircut:45:30,Color:120:90,Blowout:35:30"

This script writes to the VoiceAI_Platform DynamoDB table.
"""

import argparse
import json
import sys

import boto3
from botocore.exceptions import ClientError

TABLE_NAME = "VoiceAI_Platform"
REGION = "us-west-2"

# ── Demo tenant data ───────────────────────────────────────────────

DEMO_TENANTS = {
    "barbershop": {
        "tenant_id": "t_001",
        "business_name": "Elite Cuts Barbershop",
        "business_type": "barbershop",
        "timezone": "America/Los_Angeles",
        "phone": "+14259529066",
        "voice_id": "f786b574-daa5-4673-aa0c-cbe3e8534c02",  # Katie — Female American English
        "greeting_name": "Elite Cuts Barbershop",
        "slot_duration_minutes": 30,
        "enabled_channels": ["phone", "email", "booking_page"],
        "email_subdomain": "elitecuts",
        "google_calendar_id": "manishdev2311@gmail.com",
        "hours": {
            "open": 9,
            "close": 19,
            "days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        },
        "staff": [
            {"name": "Jake", "title": "Senior Barber", "specialties": ["fades", "classic cuts"]},
            {"name": "Marco", "title": "Barber", "specialties": ["beard trims", "hot shaves"]},
            {"name": "Sofia", "title": "Stylist", "specialties": ["modern styles", "kids cuts"]},
        ],
        "services": [
            {"name": "Haircut", "price": 25, "duration_minutes": 30},
            {"name": "Beard Trim", "price": 15, "duration_minutes": 15},
            {"name": "Shave", "price": 20, "duration_minutes": 20},
            {"name": "Kids Cut", "price": 20, "duration_minutes": 20},
            {"name": "Hair Wash & Style", "price": 30, "duration_minutes": 30},
            {"name": "Full Service", "price": 35, "duration_minutes": 45},
        ],
    },
    "barbershop_test": {
        "tenant_id": "t_test_001",
        "business_name": "Elite Cuts Barbershop (TEST)",
        "business_type": "barbershop",
        "timezone": "America/Los_Angeles",
        "phone": "+14255347267",
        "voice_id": "f786b574-daa5-4673-aa0c-cbe3e8534c02",
        "greeting_name": "Elite Cuts Barbershop",
        "slot_duration_minutes": 30,
        "enabled_channels": ["phone", "sms", "web_chat", "email", "booking_page"],
        "sms_phone": "+14255347267",
        "email_subdomain": "elitecuts-test",
        "google_calendar_id": "manishdev2311@gmail.com",
        "hours": {
            "open": 9,
            "close": 19,
            "days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        },
        "staff": [
            {"name": "Jake", "title": "Senior Barber", "specialties": ["fades", "classic cuts"]},
            {"name": "Marco", "title": "Barber", "specialties": ["beard trims", "hot shaves"]},
            {"name": "Sofia", "title": "Stylist", "specialties": ["modern styles", "kids cuts"]},
        ],
        "services": [
            {"name": "Haircut", "price": 25, "duration_minutes": 30},
            {"name": "Beard Trim", "price": 15, "duration_minutes": 15},
            {"name": "Shave", "price": 20, "duration_minutes": 20},
            {"name": "Kids Cut", "price": 20, "duration_minutes": 20},
            {"name": "Hair Wash & Style", "price": 30, "duration_minutes": 30},
            {"name": "Full Service", "price": 35, "duration_minutes": 45},
        ],
    },
    "dentist": {
        "tenant_id": "t_002",
        "business_name": "Smile Dental Care",
        "business_type": "dentist",
        "timezone": "America/Los_Angeles",
        "phone": "+15551234567",  # Placeholder — update with real Twilio number
        "voice_id": "f786b574-daa5-4673-aa0c-cbe3e8534c02",  # Same voice for now
        "greeting_name": "Smile Dental Care",
        "slot_duration_minutes": 30,
        "enabled_channels": ["phone"],
        "hours": {
            "open": 8,
            "close": 17,
            "days": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        },
        "staff": [
            {"name": "Dr. Smith", "title": "General Dentist", "specialties": ["cleanings", "fillings"]},
            {"name": "Dr. Patel", "title": "Orthodontist", "specialties": ["braces", "aligners"]},
        ],
        "services": [
            {"name": "Teeth Cleaning", "price": 150, "duration_minutes": 60},
            {"name": "Dental Exam", "price": 100, "duration_minutes": 30},
            {"name": "Filling", "price": 200, "duration_minutes": 45},
            {"name": "Root Canal", "price": 800, "duration_minutes": 120},
            {"name": "Teeth Whitening", "price": 300, "duration_minutes": 60},
            {"name": "Crown", "price": 1200, "duration_minutes": 90},
        ],
    },
}


def seed_tenant(tenant_data: dict):
    """Write a complete tenant configuration to DynamoDB."""
    table = boto3.resource("dynamodb", region_name=REGION).Table(TABLE_NAME)
    tenant_id = tenant_data["tenant_id"]

    channels = tenant_data.get("enabled_channels", ["phone"])
    print(f"\nSeeding tenant: {tenant_data['business_name']} ({tenant_id})")
    print(f"  Type: {tenant_data['business_type']}")
    print(f"  Phone: {tenant_data['phone']}")
    print(f"  Channels: {', '.join(channels)}")
    if tenant_data.get("sms_phone"):
        print(f"  SMS Phone: {tenant_data['sms_phone']}")
    if tenant_data.get("email_subdomain"):
        print(f"  Email: book@{tenant_data['email_subdomain']}.prodvoice.link")
    if tenant_data.get("google_calendar_id"):
        print(f"  Google Calendar: {tenant_data['google_calendar_id']}")
    print()

    # 1. Write tenant CONFIG
    print(f"  Writing CONFIG...")
    config_item = {
        "PK": f"TENANT#{tenant_id}",
        "SK": "CONFIG",
        "business_name": tenant_data["business_name"],
        "business_type": tenant_data["business_type"],
        "timezone": tenant_data["timezone"],
        "hours": tenant_data["hours"],
        "voice_id": tenant_data["voice_id"],
        "greeting_name": tenant_data["greeting_name"],
        "slot_duration_minutes": tenant_data["slot_duration_minutes"],
        "enabled_channels": tenant_data.get("enabled_channels", ["phone"]),
    }
    # Add optional channel-specific fields
    if tenant_data.get("sms_phone"):
        config_item["sms_phone"] = tenant_data["sms_phone"]
    if tenant_data.get("whatsapp_phone"):
        config_item["whatsapp_phone"] = tenant_data["whatsapp_phone"]
    if tenant_data.get("email_subdomain"):
        config_item["email_subdomain"] = tenant_data["email_subdomain"]
    if tenant_data.get("google_calendar_id"):
        config_item["google_calendar_id"] = tenant_data["google_calendar_id"]
    table.put_item(Item=config_item)

    # 2. Write STAFF members
    for staff in tenant_data["staff"]:
        print(f"  Writing STAFF#{staff['name']}...")
        table.put_item(
            Item={
                "PK": f"TENANT#{tenant_id}",
                "SK": f"STAFF#{staff['name']}",
                "name": staff["name"],
                "title": staff["title"],
                "specialties": staff.get("specialties", []),
            }
        )

    # 3. Write SERVICES
    for svc in tenant_data["services"]:
        print(f"  Writing SERVICE#{svc['name']}...")
        table.put_item(
            Item={
                "PK": f"TENANT#{tenant_id}",
                "SK": f"SERVICE#{svc['name']}",
                "name": svc["name"],
                "price": svc["price"],
                "duration_minutes": svc["duration_minutes"],
            }
        )

    # 4. Write PHONE mapping
    print(f"  Writing PHONE#{tenant_data['phone']}...")
    table.put_item(
        Item={
            "PK": f"PHONE#{tenant_data['phone']}",
            "SK": "MAPPING",
            "tenant_id": tenant_id,
            "business_name": tenant_data["business_name"],
        }
    )

    # 5. Write EMAIL mapping (if email subdomain configured)
    email_subdomain = tenant_data.get("email_subdomain", "")
    if email_subdomain:
        print(f"  Writing EMAIL#{email_subdomain}...")
        table.put_item(
            Item={
                "PK": f"EMAIL#{email_subdomain}",
                "SK": "MAPPING",
                "tenant_id": tenant_id,
                "business_name": tenant_data["business_name"],
                "email_address": f"book@{email_subdomain}.prodvoice.link",
            }
        )

    staff_count = len(tenant_data["staff"])
    svc_count = len(tenant_data["services"])
    mappings = 1 + (1 if email_subdomain else 0)
    print()
    print(f"  Done! Seeded {staff_count} staff + {svc_count} services + {mappings} mapping(s)")
    print(f"  Phone {tenant_data['phone']} -> {tenant_id} ({tenant_data['business_name']})")
    if email_subdomain:
        print(f"  Email book@{email_subdomain}.prodvoice.link -> {tenant_id}")


def parse_custom_args(args) -> dict:
    """Parse custom CLI arguments into a tenant data dict."""
    # Parse hours JSON
    try:
        hours = json.loads(args.hours)
    except json.JSONDecodeError:
        print(f"ERROR: Invalid JSON for --hours: {args.hours}")
        sys.exit(1)

    # Parse staff: "Name:Title,Name:Title"
    staff = []
    for entry in args.staff.split(","):
        parts = entry.strip().split(":")
        if len(parts) < 2:
            print(f"ERROR: Staff format should be 'Name:Title'. Got: {entry}")
            sys.exit(1)
        staff.append({"name": parts[0].strip(), "title": parts[1].strip(), "specialties": []})

    # Parse services: "Name:Price:Duration,Name:Price:Duration"
    services = []
    for entry in args.services.split(","):
        parts = entry.strip().split(":")
        if len(parts) < 3:
            print(f"ERROR: Service format should be 'Name:Price:DurationMinutes'. Got: {entry}")
            sys.exit(1)
        services.append({
            "name": parts[0].strip(),
            "price": int(parts[1].strip()),
            "duration_minutes": int(parts[2].strip()),
        })

    # Parse channels
    enabled_channels = ["phone"]
    if args.channels:
        enabled_channels = [c.strip() for c in args.channels.split(",")]

    result = {
        "tenant_id": args.id,
        "business_name": args.name,
        "business_type": args.type,
        "timezone": args.timezone or "America/Los_Angeles",
        "phone": args.phone,
        "voice_id": args.voice_id or "f786b574-daa5-4673-aa0c-cbe3e8534c02",
        "greeting_name": args.greeting or args.name,
        "slot_duration_minutes": args.slot_duration or 30,
        "enabled_channels": enabled_channels,
        "hours": hours,
        "staff": staff,
        "services": services,
    }

    # SMS phone (default: same as voice phone)
    if "sms" in enabled_channels:
        result["sms_phone"] = args.sms_phone or args.phone

    # Email subdomain
    if "email" in enabled_channels and args.email_subdomain:
        result["email_subdomain"] = args.email_subdomain

    # Google Calendar
    if args.google_calendar_id:
        result["google_calendar_id"] = args.google_calendar_id

    return result


def main():
    parser = argparse.ArgumentParser(
        description="Seed a new tenant into the VoiceAI Platform"
    )

    # Demo mode
    parser.add_argument(
        "--demo",
        choices=["barbershop", "barbershop_test", "dentist", "all"],
        help="Seed a pre-configured demo tenant (barbershop_test includes SMS + web_chat)",
    )

    # Custom tenant mode
    parser.add_argument("--id", help="Tenant ID (e.g. t_003)")
    parser.add_argument("--name", help="Business name")
    parser.add_argument("--type", help="Business type (barbershop, dentist, doctor, salon)")
    parser.add_argument("--phone", help="Twilio phone number (e.g. +14255347267)")
    parser.add_argument("--hours", help='Business hours JSON (e.g. \'{"open":9,"close":17,"days":["Mon"]}\')')
    parser.add_argument("--staff", help='Staff list: "Name:Title,Name:Title"')
    parser.add_argument("--services", help='Services: "Name:Price:Duration,Name:Price:Duration"')
    parser.add_argument("--timezone", help="Timezone (default: America/Los_Angeles)")
    parser.add_argument("--voice-id", dest="voice_id", help="Cartesia voice ID")
    parser.add_argument("--greeting", help="Greeting name (default: business name)")
    parser.add_argument("--slot-duration", dest="slot_duration", type=int, help="Slot duration in minutes (default: 30)")
    parser.add_argument("--channels", help='Comma-separated channels: "phone,sms,web_chat,whatsapp,email"')
    parser.add_argument("--sms-phone", dest="sms_phone", help="Twilio phone for SMS (default: same as --phone)")
    parser.add_argument("--email-subdomain", dest="email_subdomain", help="Email subdomain (e.g. 'elitecuts' for book@elitecuts.prodvoice.link)")
    parser.add_argument("--google-calendar-id", dest="google_calendar_id", help="Google Calendar ID for appointment sync")

    args = parser.parse_args()

    if args.demo:
        if args.demo == "all":
            for name, data in DEMO_TENANTS.items():
                seed_tenant(data)
        else:
            seed_tenant(DEMO_TENANTS[args.demo])
    elif args.id and args.name and args.type and args.phone and args.hours and args.staff and args.services:
        tenant_data = parse_custom_args(args)
        seed_tenant(tenant_data)
    else:
        print("ERROR: Either use --demo or provide all custom fields:")
        print("  --id, --name, --type, --phone, --hours, --staff, --services")
        print()
        print("Examples:")
        print("  uv run seed_tenant.py --demo barbershop")
        print("  uv run seed_tenant.py --demo dentist")
        print("  uv run seed_tenant.py --demo all")
        print()
        parser.print_help()
        sys.exit(1)

    print()
    print("Tenant seeded successfully!")


if __name__ == "__main__":
    main()
