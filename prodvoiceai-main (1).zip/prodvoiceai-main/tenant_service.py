"""Tenant service — loads and caches tenant configuration from DynamoDB.

Handles:
- Phone number → tenant_id lookup
- Email subdomain → tenant_id lookup
- Full tenant config loading (business info, staff, services)
- In-memory caching with TTL to avoid repeated DynamoDB reads

DynamoDB key patterns:
  Phone mapping:  PK=PHONE#+14255347267  SK=MAPPING
  Email mapping:  PK=EMAIL#elitecuts     SK=MAPPING
  Tenant config:  PK=TENANT#t_001        SK=CONFIG
  Staff members:  PK=TENANT#t_001        SK=STAFF#Jake
  Services:       PK=TENANT#t_001        SK=SERVICE#Haircut
"""

import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional

import boto3
from boto3.dynamodb.conditions import Key
from loguru import logger

TABLE_NAME = "VoiceAI_Platform"
REGION = "us-west-2"

# Cache TTL in seconds (5 minutes)
CACHE_TTL = 300


@dataclass
class StaffMember:
    name: str
    title: str
    specialties: list[str] = field(default_factory=list)


@dataclass
class Service:
    name: str
    price: float
    duration_minutes: int


@dataclass
class TenantConfig:
    """Complete configuration for a single tenant (business customer)."""

    tenant_id: str
    business_name: str
    business_type: str  # "barbershop", "dentist", "doctor", etc.
    timezone: str
    hours: dict  # {"open": 9, "close": 19, "days": ["Monday", ...]}
    voice_id: str  # Cartesia voice ID
    greeting_name: str  # What the AI calls itself, e.g. "Elite Cuts Barbershop"
    staff: list[StaffMember] = field(default_factory=list)
    services: list[Service] = field(default_factory=list)
    slot_duration_minutes: int = 30  # Default slot size

    # ── Channel configuration ──
    enabled_channels: list[str] = field(default_factory=lambda: ["phone"])
    sms_phone: str = ""  # Twilio number for SMS (can differ from voice)
    whatsapp_phone: str = ""  # WhatsApp-enabled Twilio number
    email_subdomain: str = ""  # Email subdomain (e.g. "elitecuts" → book@elitecuts.prodvoice.link)
    google_calendar_id: str = ""  # Google Calendar ID for appointment sync

    @property
    def staff_names(self) -> list[str]:
        return [s.name for s in self.staff]

    @property
    def service_names(self) -> list[str]:
        return [s.name for s in self.services]

    @property
    def service_map(self) -> dict[str, Service]:
        return {s.name: s for s in self.services}

    @property
    def all_slots(self) -> list[str]:
        """Generate all valid time slots based on business hours and slot duration."""
        slots = []
        open_hour = self.hours["open"]
        close_hour = self.hours["close"]
        duration = self.slot_duration_minutes
        current_minutes = open_hour * 60
        end_minutes = close_hour * 60 - duration  # Last bookable slot
        while current_minutes <= end_minutes:
            h = current_minutes // 60
            m = current_minutes % 60
            slots.append(f"{h:02d}:{m:02d}")
            current_minutes += duration
        return slots

    @property
    def open_days(self) -> list[str]:
        return self.hours.get("days", [])


# ── DynamoDB table (lazy init) ──────────────────────────────────────

_dynamodb_table = None


def _get_table():
    global _dynamodb_table
    if _dynamodb_table is None:
        dynamodb = boto3.resource("dynamodb", region_name=REGION)
        _dynamodb_table = dynamodb.Table(TABLE_NAME)
    return _dynamodb_table


# ── In-memory cache ─────────────────────────────────────────────────

_phone_cache: dict[str, tuple[str, float]] = {}  # phone -> (tenant_id, timestamp)
_tenant_cache: dict[str, tuple[TenantConfig, float]] = {}  # tenant_id -> (config, timestamp)


def _cache_valid(timestamp: float) -> bool:
    return (time.time() - timestamp) < CACHE_TTL


def clear_cache():
    """Clear all cached data. Useful for testing."""
    _phone_cache.clear()
    _tenant_cache.clear()


# ── Sync helpers (run in asyncio.to_thread) ─────────────────────────


def _lookup_tenant_by_phone_sync(phone_number: str) -> Optional[str]:
    """Look up tenant_id from a phone number. Returns None if not found."""
    # Check cache
    if phone_number in _phone_cache:
        tenant_id, ts = _phone_cache[phone_number]
        if _cache_valid(ts):
            logger.debug(f"Phone cache hit: {phone_number} -> {tenant_id}")
            return tenant_id

    table = _get_table()
    response = table.get_item(
        Key={"PK": f"PHONE#{phone_number}", "SK": "MAPPING"}
    )
    item = response.get("Item")

    if not item:
        logger.warning(f"No tenant found for phone number: {phone_number}")
        return None

    tenant_id = item["tenant_id"]
    _phone_cache[phone_number] = (tenant_id, time.time())
    logger.info(f"Phone lookup: {phone_number} -> {tenant_id}")
    return tenant_id


def _load_tenant_config_sync(tenant_id: str) -> Optional[TenantConfig]:
    """Load full tenant config (business info + staff + services) from DynamoDB."""
    # Check cache
    if tenant_id in _tenant_cache:
        config, ts = _tenant_cache[tenant_id]
        if _cache_valid(ts):
            logger.debug(f"Tenant cache hit: {tenant_id}")
            return config

    table = _get_table()
    pk = f"TENANT#{tenant_id}"

    # Query all items for this tenant (CONFIG, STAFF#*, SERVICE#*)
    response = table.query(KeyConditionExpression=Key("PK").eq(pk))
    items = response["Items"]

    if not items:
        logger.error(f"No config found for tenant: {tenant_id}")
        return None

    # Parse items by SK prefix
    config_item = None
    staff_list = []
    service_list = []

    for item in items:
        sk = item["SK"]
        if sk == "CONFIG":
            config_item = item
        elif sk.startswith("STAFF#"):
            staff_list.append(
                StaffMember(
                    name=item["name"],
                    title=item.get("title", ""),
                    specialties=item.get("specialties", []),
                )
            )
        elif sk.startswith("SERVICE#"):
            service_list.append(
                Service(
                    name=item["name"],
                    price=float(item["price"]),
                    duration_minutes=int(item["duration_minutes"]),
                )
            )

    if not config_item:
        logger.error(f"CONFIG item missing for tenant: {tenant_id}")
        return None

    # DynamoDB returns numbers as Decimal — convert hours to native Python ints
    raw_hours = config_item["hours"]
    hours = {
        "open": int(raw_hours["open"]),
        "close": int(raw_hours["close"]),
        "days": raw_hours.get("days", []),
    }

    tenant_config = TenantConfig(
        tenant_id=tenant_id,
        business_name=config_item["business_name"],
        business_type=config_item["business_type"],
        timezone=config_item.get("timezone", "America/Los_Angeles"),
        hours=hours,
        voice_id=config_item.get("voice_id", "f786b574-daa5-4673-aa0c-cbe3e8534c02"),
        greeting_name=config_item.get("greeting_name", config_item["business_name"]),
        staff=staff_list,
        services=service_list,
        slot_duration_minutes=int(config_item.get("slot_duration_minutes", 30)),
        # Channel config (backwards compatible — defaults to phone only)
        enabled_channels=config_item.get("enabled_channels", ["phone"]),
        sms_phone=config_item.get("sms_phone", ""),
        whatsapp_phone=config_item.get("whatsapp_phone", ""),
        email_subdomain=config_item.get("email_subdomain", ""),
        google_calendar_id=config_item.get("google_calendar_id", ""),
    )

    _tenant_cache[tenant_id] = (tenant_config, time.time())
    logger.info(
        f"Loaded tenant config: {tenant_config.business_name} "
        f"({len(staff_list)} staff, {len(service_list)} services)"
    )
    return tenant_config


def _lookup_tenant_by_sms_phone_sync(sms_phone: str) -> Optional[str]:
    """Look up tenant_id from an SMS phone number.

    First checks PHONE# mapping (works if SMS uses same number as voice).
    If not found, scans for tenants with matching sms_phone field.
    """
    # Try the standard phone mapping first (most common: same number for voice + SMS)
    result = _lookup_tenant_by_phone_sync(sms_phone)
    if result:
        return result

    # Fall back: scan for tenants with this sms_phone
    # (This is only needed if SMS uses a different number than voice)
    table = _get_table()
    # We'd need a GSI for this in production. For now, this path is rarely hit
    # because most setups use the same number for voice + SMS.
    logger.warning(f"SMS phone {sms_phone} not in PHONE# mapping, no tenant found")
    return None


def _lookup_tenant_by_email_sync(subdomain: str) -> Optional[str]:
    """Look up tenant_id from an email subdomain.

    Checks DynamoDB for EMAIL#{subdomain} -> MAPPING item.
    E.g., EMAIL#elitecuts -> t_001
    """
    subdomain = subdomain.lower().strip()

    # Check cache
    cache_key = f"email:{subdomain}"
    if cache_key in _phone_cache:
        tenant_id, ts = _phone_cache[cache_key]
        if _cache_valid(ts):
            logger.debug(f"Email cache hit: {subdomain} -> {tenant_id}")
            return tenant_id

    table = _get_table()
    response = table.get_item(
        Key={"PK": f"EMAIL#{subdomain}", "SK": "MAPPING"}
    )
    item = response.get("Item")

    if not item:
        logger.warning(f"No tenant found for email subdomain: {subdomain}")
        return None

    tenant_id = item["tenant_id"]
    _phone_cache[cache_key] = (tenant_id, time.time())
    logger.info(f"Email lookup: {subdomain} -> {tenant_id}")
    return tenant_id


# ── Public async API ────────────────────────────────────────────────


async def lookup_tenant_by_phone(phone_number: str) -> Optional[str]:
    """Look up tenant_id from a Twilio phone number."""
    return await asyncio.to_thread(_lookup_tenant_by_phone_sync, phone_number)


async def lookup_tenant_by_sms_phone(sms_phone: str) -> Optional[str]:
    """Look up tenant_id from an SMS phone number."""
    return await asyncio.to_thread(_lookup_tenant_by_sms_phone_sync, sms_phone)


async def lookup_tenant_by_email(subdomain: str) -> Optional[str]:
    """Look up tenant_id from an email subdomain (e.g. 'elitecuts')."""
    return await asyncio.to_thread(_lookup_tenant_by_email_sync, subdomain)


async def load_tenant_config(tenant_id: str) -> Optional[TenantConfig]:
    """Load full tenant config from DynamoDB (with caching)."""
    return await asyncio.to_thread(_load_tenant_config_sync, tenant_id)


async def get_tenant_by_phone(phone_number: str) -> Optional[TenantConfig]:
    """Convenience: phone number -> full tenant config in one call."""
    tenant_id = await lookup_tenant_by_phone(phone_number)
    if not tenant_id:
        return None
    return await load_tenant_config(tenant_id)
