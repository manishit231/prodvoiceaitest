"""Create the DynamoDB table for the multi-tenant VoiceAI Platform.

Single-table design: all tenants, configs, appointments share one table.
Data isolation is achieved via key prefixing (TENANT#, PHONE#, APPT#).

Run once:
    uv run aws_setup.py
"""

import boto3
from botocore.exceptions import ClientError

TABLE_NAME = "VoiceAI_Platform"
REGION = "us-west-2"


def create_table():
    dynamodb = boto3.client("dynamodb", region_name=REGION)

    # Check if table already exists
    try:
        dynamodb.describe_table(TableName=TABLE_NAME)
        print(f"Table '{TABLE_NAME}' already exists. No action needed.")
        return
    except ClientError as e:
        if e.response["Error"]["Code"] != "ResourceNotFoundException":
            raise

    print(f"Creating table '{TABLE_NAME}' in {REGION}...")

    dynamodb.create_table(
        TableName=TABLE_NAME,
        KeySchema=[
            {"AttributeName": "PK", "KeyType": "HASH"},
            {"AttributeName": "SK", "KeyType": "RANGE"},
        ],
        AttributeDefinitions=[
            {"AttributeName": "PK", "AttributeType": "S"},
            {"AttributeName": "SK", "AttributeType": "S"},
            {"AttributeName": "GSI1PK", "AttributeType": "S"},
            {"AttributeName": "GSI1SK", "AttributeType": "S"},
        ],
        GlobalSecondaryIndexes=[
            {
                "IndexName": "GSI1",
                "KeySchema": [
                    {"AttributeName": "GSI1PK", "KeyType": "HASH"},
                    {"AttributeName": "GSI1SK", "KeyType": "RANGE"},
                ],
                "Projection": {"ProjectionType": "ALL"},
            }
        ],
        BillingMode="PAY_PER_REQUEST",
    )

    # Wait for table to become active
    print("Waiting for table to become active...")
    waiter = dynamodb.get_waiter("table_exists")
    waiter.wait(TableName=TABLE_NAME)
    print(f"Table '{TABLE_NAME}' created successfully!")
    print()
    print("Key schema:")
    print("  PK (Partition Key) / SK (Sort Key)")
    print()
    print("Entity patterns:")
    print("  Tenant Config:  PK=TENANT#t_001        SK=CONFIG")
    print("  Staff Member:   PK=TENANT#t_001        SK=STAFF#Jake")
    print("  Service:        PK=TENANT#t_001        SK=SERVICE#Haircut")
    print("  Phone Mapping:  PK=PHONE#+14255347267  SK=MAPPING")
    print("  Appointment:    PK=APPT#t_001#Jake#2026-02-14  SK=14:00")
    print()
    print("GSI1 (Customer Lookup):")
    print("  GSI1PK=CUST#t_001#+15551234  GSI1SK=2026-02-14#14:00")


if __name__ == "__main__":
    create_table()
