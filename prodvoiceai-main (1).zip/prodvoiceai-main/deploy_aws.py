"""ProdVoiceAI — AWS Deployment Script.

One-command deployment to ECS Fargate with ALB, Route 53, ACM, Secrets Manager.

Usage:
    python deploy_aws.py deploy     # Create all AWS resources + deploy
    python deploy_aws.py status     # Check deployment health
    python deploy_aws.py redeploy   # Rebuild image + force new ECS deployment
    python deploy_aws.py teardown   # Delete all AWS resources
"""

import argparse
import json
import os
import subprocess
import sys
import time

# ── Configuration ─────────────────────────────────────────────────

REGION = "us-west-2"
PROJECT = "prodvoiceai"
ACCOUNT_ID = "360562519115"

# Networking
VPC_CIDR = "10.0.0.0/16"
PUBLIC_A_CIDR = "10.0.1.0/24"
PUBLIC_B_CIDR = "10.0.2.0/24"
PRIVATE_A_CIDR = "10.0.3.0/24"
PRIVATE_B_CIDR = "10.0.4.0/24"
AZ_A = f"{REGION}a"
AZ_B = f"{REGION}b"

# ECS
TASK_CPU = "1024"       # 1 vCPU
TASK_MEMORY = "4096"    # 4 GB
MIN_TASKS = 2
MAX_TASKS = 5
DESIRED_TASKS = 2

# Domain (purchased from GoDaddy)
DOMAIN = "prodvoice.link"

# Twilio phone number for webhook update
TWILIO_PHONE_SID = "PN1414fd9ebfe263de4f6a917466b014b4"

# State file
STATE_FILE = os.path.join(os.path.dirname(__file__), "deploy-state.json")
SECRETS_FILE = os.path.join(os.path.dirname(__file__), "secrets.json")

ECR_REPO = f"{ACCOUNT_ID}.dkr.ecr.{REGION}.amazonaws.com/{PROJECT}"

# Temp file for passing JSON to AWS CLI (avoids Windows quoting issues)
TMP_JSON = os.path.join(os.path.dirname(__file__), ".tmp-policy.json")


def write_tmp_json(data):
    """Write JSON data to a temp file and return the file:// URI."""
    with open(TMP_JSON, "w") as f:
        json.dump(data, f)
    return f"file://{TMP_JSON}"


def cleanup_tmp():
    if os.path.exists(TMP_JSON):
        os.remove(TMP_JSON)


# ── Helpers ───────────────────────────────────────────────────────

def run(cmd, capture=True, check=True):
    """Run a shell command and return parsed JSON output."""
    print(f"  $ {cmd[:120]}{'...' if len(cmd) > 120 else ''}")
    result = subprocess.run(
        cmd, shell=True, capture_output=capture, text=True
    )
    if check and result.returncode != 0:
        stderr = (result.stderr or "").strip() if capture else "(see output above)"
        print(f"  ERROR: {stderr}")
        return None
    if capture and result.stdout and result.stdout.strip():
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return result.stdout.strip()
    return None


def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}


def wait_for(description, check_fn, timeout=600, interval=10):
    """Poll until check_fn returns True."""
    print(f"  Waiting for {description}...")
    start = time.time()
    while time.time() - start < timeout:
        if check_fn():
            print(f"  {description} - ready!")
            return True
        time.sleep(interval)
    print(f"  TIMEOUT waiting for {description}")
    return False


# ── Stage 1: ECR ─────────────────────────────────────────────────

def create_ecr(state):
    print("\n=== Stage 1: ECR Repository ===")
    if state.get("ecr_repo"):
        print(f"  Already exists: {state['ecr_repo']}")
        return

    result = run(
        f'aws ecr create-repository --repository-name {PROJECT} '
        f'--region {REGION} --image-scanning-configuration scanOnPush=true'
    )
    if result:
        state["ecr_repo"] = result["repository"]["repositoryUri"]
        save_state(state)
        print(f"  Created: {state['ecr_repo']}")
    else:
        # Might already exist
        result = run(
            f'aws ecr describe-repositories --repository-names {PROJECT} --region {REGION}'
        )
        if result:
            state["ecr_repo"] = result["repositories"][0]["repositoryUri"]
            save_state(state)
            print(f"  Already exists: {state['ecr_repo']}")


# ── Stage 2: Secrets Manager ─────────────────────────────────────

def create_secrets(state):
    print("\n=== Stage 2: Secrets Manager ===")
    if state.get("secret_arn"):
        print(f"  Already exists: {state['secret_arn']}")
        return

    if not os.path.exists(SECRETS_FILE):
        print(f"  ERROR: {SECRETS_FILE} not found. Create it with your API keys.")
        sys.exit(1)

    with open(SECRETS_FILE) as f:
        secrets = json.load(f)

    # Write secret string to a temp file (avoids shell quoting issues on Windows)
    secret_tmp = os.path.join(os.path.dirname(__file__), ".secret-tmp.json")
    with open(secret_tmp, "w") as f:
        json.dump(secrets, f)

    result = run(
        f'aws secretsmanager create-secret '
        f'--name {PROJECT}/api-keys '
        f'--region {REGION} '
        f'--secret-string file://{secret_tmp}'
    )

    # Clean up temp file
    if os.path.exists(secret_tmp):
        os.remove(secret_tmp)
    if result:
        state["secret_arn"] = result["ARN"]
        save_state(state)
        print(f"  Created: {state['secret_arn']}")
    else:
        # Might already exist — try describe
        result = run(
            f'aws secretsmanager describe-secret --secret-id {PROJECT}/api-keys --region {REGION}'
        )
        if result:
            state["secret_arn"] = result["ARN"]
            save_state(state)
            print(f"  Already exists: {state['secret_arn']}")


# ── Stage 3: VPC + Networking ────────────────────────────────────

def create_vpc(state):
    print("\n=== Stage 3: VPC + Networking ===")

    if state.get("vpc_id"):
        print(f"  VPC already exists: {state['vpc_id']}")
        return

    # Create VPC
    result = run(
        f'aws ec2 create-vpc --cidr-block {VPC_CIDR} '
        f'--tag-specifications "ResourceType=vpc,Tags=[{{Key=Name,Value={PROJECT}-vpc}}]" '
        f'--region {REGION}'
    )
    state["vpc_id"] = result["Vpc"]["VpcId"]
    save_state(state)
    print(f"  VPC: {state['vpc_id']}")

    # Enable DNS hostnames (shorthand syntax works on Windows)
    run(f'aws ec2 modify-vpc-attribute --vpc-id {state["vpc_id"]} --enable-dns-hostnames Value=true')

    # Internet Gateway
    result = run(
        f'aws ec2 create-internet-gateway '
        f'--tag-specifications "ResourceType=internet-gateway,Tags=[{{Key=Name,Value={PROJECT}-igw}}]" '
        f'--region {REGION}'
    )
    state["igw_id"] = result["InternetGateway"]["InternetGatewayId"]
    run(f'aws ec2 attach-internet-gateway --vpc-id {state["vpc_id"]} --internet-gateway-id {state["igw_id"]}')
    print(f"  IGW: {state['igw_id']}")

    # Subnets
    for name, cidr, az, key in [
        ("public-a", PUBLIC_A_CIDR, AZ_A, "subnet_public_a"),
        ("public-b", PUBLIC_B_CIDR, AZ_B, "subnet_public_b"),
        ("private-a", PRIVATE_A_CIDR, AZ_A, "subnet_private_a"),
        ("private-b", PRIVATE_B_CIDR, AZ_B, "subnet_private_b"),
    ]:
        result = run(
            f'aws ec2 create-subnet --vpc-id {state["vpc_id"]} '
            f'--cidr-block {cidr} --availability-zone {az} '
            f'--tag-specifications "ResourceType=subnet,Tags=[{{Key=Name,Value={PROJECT}-{name}}}]" '
            f'--region {REGION}'
        )
        state[key] = result["Subnet"]["SubnetId"]
        print(f"  Subnet {name}: {state[key]}")

    # Enable auto-assign public IP on public subnets
    for key in ["subnet_public_a", "subnet_public_b"]:
        run(f'aws ec2 modify-subnet-attribute --subnet-id {state[key]} --map-public-ip-on-launch')

    # Elastic IP for NAT Gateway
    result = run(
        f'aws ec2 allocate-address --domain vpc '
        f'--tag-specifications "ResourceType=elastic-ip,Tags=[{{Key=Name,Value={PROJECT}-nat-eip}}]" '
        f'--region {REGION}'
    )
    state["eip_alloc"] = result["AllocationId"]
    print(f"  EIP: {state['eip_alloc']}")

    # NAT Gateway
    result = run(
        f'aws ec2 create-nat-gateway --subnet-id {state["subnet_public_a"]} '
        f'--allocation-id {state["eip_alloc"]} '
        f'--tag-specifications "ResourceType=natgateway,Tags=[{{Key=Name,Value={PROJECT}-nat}}]" '
        f'--region {REGION}'
    )
    state["nat_gw_id"] = result["NatGateway"]["NatGatewayId"]
    print(f"  NAT Gateway: {state['nat_gw_id']} (waiting for availability...)")
    save_state(state)

    # Wait for NAT Gateway to be available
    wait_for(
        "NAT Gateway",
        lambda: run(
            f'aws ec2 describe-nat-gateways --nat-gateway-ids {state["nat_gw_id"]} --region {REGION}',
            check=False
        ) and run(
            f'aws ec2 describe-nat-gateways --nat-gateway-ids {state["nat_gw_id"]} --region {REGION}',
            check=False
        )["NatGateways"][0]["State"] == "available",
        timeout=300,
        interval=15,
    )

    # Public route table
    result = run(
        f'aws ec2 create-route-table --vpc-id {state["vpc_id"]} '
        f'--tag-specifications "ResourceType=route-table,Tags=[{{Key=Name,Value={PROJECT}-public-rt}}]" '
        f'--region {REGION}'
    )
    state["public_rt"] = result["RouteTable"]["RouteTableId"]
    run(
        f'aws ec2 create-route --route-table-id {state["public_rt"]} '
        f'--destination-cidr-block 0.0.0.0/0 --gateway-id {state["igw_id"]}'
    )
    for key in ["subnet_public_a", "subnet_public_b"]:
        run(f'aws ec2 associate-route-table --route-table-id {state["public_rt"]} --subnet-id {state[key]}')
    print(f"  Public RT: {state['public_rt']}")

    # Private route table
    result = run(
        f'aws ec2 create-route-table --vpc-id {state["vpc_id"]} '
        f'--tag-specifications "ResourceType=route-table,Tags=[{{Key=Name,Value={PROJECT}-private-rt}}]" '
        f'--region {REGION}'
    )
    state["private_rt"] = result["RouteTable"]["RouteTableId"]
    run(
        f'aws ec2 create-route --route-table-id {state["private_rt"]} '
        f'--destination-cidr-block 0.0.0.0/0 --nat-gateway-id {state["nat_gw_id"]}'
    )
    for key in ["subnet_private_a", "subnet_private_b"]:
        run(f'aws ec2 associate-route-table --route-table-id {state["private_rt"]} --subnet-id {state[key]}')
    print(f"  Private RT: {state['private_rt']}")

    save_state(state)


# ── Stage 4: Security Groups ────────────────────────────────────

def create_security_groups(state):
    print("\n=== Stage 4: Security Groups ===")

    if state.get("alb_sg") and state.get("ecs_sg"):
        print(f"  Already exist: ALB={state['alb_sg']}, ECS={state['ecs_sg']}")
        return

    # ALB Security Group
    result = run(
        f'aws ec2 create-security-group --group-name {PROJECT}-alb-sg '
        f'--description "ALB for {PROJECT}" --vpc-id {state["vpc_id"]} '
        f'--region {REGION}'
    )
    state["alb_sg"] = result["GroupId"]
    run(f'aws ec2 authorize-security-group-ingress --group-id {state["alb_sg"]} --protocol tcp --port 80 --cidr 0.0.0.0/0')
    run(f'aws ec2 authorize-security-group-ingress --group-id {state["alb_sg"]} --protocol tcp --port 443 --cidr 0.0.0.0/0')
    print(f"  ALB SG: {state['alb_sg']}")

    # ECS Security Group
    result = run(
        f'aws ec2 create-security-group --group-name {PROJECT}-ecs-sg '
        f'--description "ECS tasks for {PROJECT}" --vpc-id {state["vpc_id"]} '
        f'--region {REGION}'
    )
    state["ecs_sg"] = result["GroupId"]
    run(
        f'aws ec2 authorize-security-group-ingress --group-id {state["ecs_sg"]} '
        f'--protocol tcp --port 7860 --source-group {state["alb_sg"]}'
    )
    print(f"  ECS SG: {state['ecs_sg']}")

    save_state(state)


# ── Stage 5: ALB ─────────────────────────────────────────────────

def create_alb(state):
    print("\n=== Stage 5: Application Load Balancer ===")

    if state.get("alb_arn"):
        print(f"  Already exists: {state.get('alb_dns')}")
        return

    # Create ALB
    result = run(
        f'aws elbv2 create-load-balancer --name {PROJECT}-alb '
        f'--subnets {state["subnet_public_a"]} {state["subnet_public_b"]} '
        f'--security-groups {state["alb_sg"]} '
        f'--scheme internet-facing --type application --region {REGION}'
    )
    state["alb_arn"] = result["LoadBalancers"][0]["LoadBalancerArn"]
    state["alb_dns"] = result["LoadBalancers"][0]["DNSName"]
    state["alb_hosted_zone"] = result["LoadBalancers"][0]["CanonicalHostedZoneId"]
    print(f"  ALB: {state['alb_dns']}")

    # Set idle timeout to 3600s for long WebSocket calls
    run(
        f'aws elbv2 modify-load-balancer-attributes --load-balancer-arn {state["alb_arn"]} '
        f'--attributes Key=idle_timeout.timeout_seconds,Value=3600 --region {REGION}'
    )
    print("  Idle timeout: 3600s")

    # Create Target Group
    result = run(
        f'aws elbv2 create-target-group --name {PROJECT}-tg '
        f'--protocol HTTP --port 7860 --vpc-id {state["vpc_id"]} '
        f'--target-type ip '
        f'--health-check-protocol HTTP --health-check-path /health '
        f'--health-check-interval-seconds 30 --health-check-timeout-seconds 10 '
        f'--healthy-threshold-count 2 --unhealthy-threshold-count 5 '
        f'--matcher HttpCode=200 --region {REGION}'
    )
    state["tg_arn"] = result["TargetGroups"][0]["TargetGroupArn"]
    print(f"  Target Group: {state['tg_arn']}")

    # HTTP Listener (temporary — will redirect to HTTPS after cert is ready)
    result = run(
        f'aws elbv2 create-listener --load-balancer-arn {state["alb_arn"]} '
        f'--protocol HTTP --port 80 '
        f'--default-actions Type=forward,TargetGroupArn={state["tg_arn"]} '
        f'--region {REGION}'
    )
    state["http_listener_arn"] = result["Listeners"][0]["ListenerArn"]
    print(f"  HTTP Listener: port 80")

    save_state(state)


# ── Stage 6: Domain + SSL ────────────────────────────────────────

def create_domain_and_ssl(state):
    print("\n=== Stage 6: Domain + ACM Certificate ===")

    domain = DOMAIN
    state["domain"] = domain
    print(f"  Domain: {domain} (purchased from GoDaddy)")

    # Check if hosted zone exists
    result = run(f'aws route53 list-hosted-zones-by-name --dns-name {domain} --region {REGION}')
    hosted_zones = [hz for hz in result["HostedZones"] if hz["Name"].rstrip(".") == domain]

    if hosted_zones:
        state["hosted_zone_id"] = hosted_zones[0]["Id"].split("/")[-1]
        print(f"  Hosted zone already exists: {state['hosted_zone_id']}")
    else:
        result = run(
            f'aws route53 create-hosted-zone --name {domain} '
            f'--caller-reference {PROJECT}-{int(time.time())}'
        )
        state["hosted_zone_id"] = result["HostedZone"]["Id"].split("/")[-1]
        print(f"  Created hosted zone: {state['hosted_zone_id']}")

    save_state(state)

    # Get the Route 53 nameservers — user must set these in GoDaddy
    result = run(
        f'aws route53 get-hosted-zone --id {state["hosted_zone_id"]}'
    )
    if result:
        nameservers = result["DelegationSet"]["NameServers"]
        state["nameservers"] = nameservers
        save_state(state)
        print()
        print("  +--------------------------------------------------------------+")
        print("  |  ACTION REQUIRED: Change nameservers in GoDaddy             |")
        print("  |                                                             |")
        print("  |  Go to: godaddy.com -> My Products -> prodvoice.link        |")
        print("  |  Click: DNS -> Nameservers -> Change -> Custom              |")
        print("  |  Enter these 4 nameservers:                                 |")
        for ns in nameservers:
            print(f"  |    {ns:<56}|")
        print("  |                                                             |")
        print("  |  Save and wait 5-30 min for DNS propagation.                |")
        print("  |  The deploy will continue with SSL cert setup now.          |")
        print("  +--------------------------------------------------------------+")
        print()

    # Request ACM certificate
    if not state.get("cert_arn"):
        result = run(
            f'aws acm request-certificate --domain-name {domain} '
            f'--validation-method DNS --region {REGION}'
        )
        state["cert_arn"] = result["CertificateArn"]
        save_state(state)
        print(f"  Certificate requested: {state['cert_arn']}")

        # Wait a moment for validation records to appear
        time.sleep(5)

        # Get DNS validation record
        result = run(
            f'aws acm describe-certificate --certificate-arn {state["cert_arn"]} --region {REGION}'
        )
        validation = result["Certificate"]["DomainValidationOptions"][0]
        if "ResourceRecord" in validation:
            rr = validation["ResourceRecord"]
            # Create DNS validation record in Route 53
            change_batch = {
                "Changes": [{
                    "Action": "UPSERT",
                    "ResourceRecordSet": {
                        "Name": rr["Name"],
                        "Type": rr["Type"],
                        "TTL": 300,
                        "ResourceRecords": [{"Value": rr["Value"]}]
                    }
                }]
            }
            cb_uri = write_tmp_json(change_batch)
            run(
                f"aws route53 change-resource-record-sets "
                f"--hosted-zone-id {state['hosted_zone_id']} "
                f"--change-batch {cb_uri}"
            )
            cleanup_tmp()
            print(f"  DNS validation record created")
        else:
            print("  Waiting for validation records... run 'deploy' again in a minute")
            return

    # Check if certificate is already validated
    cert_result = run(
        f'aws acm describe-certificate --certificate-arn {state["cert_arn"]} --region {REGION}',
        check=False
    )
    cert_status = cert_result["Certificate"]["Status"] if cert_result else "UNKNOWN"

    if cert_status == "ISSUED":
        print(f"  Certificate already validated!")
    else:
        # Wait for certificate to be validated (needs GoDaddy nameservers pointed to Route 53)
        print(f"  Certificate status: {cert_status}")
        print("  Waiting for ACM certificate validation (needs GoDaddy nameservers changed)...")
        cert_ready = wait_for(
            "ACM certificate validation",
            lambda: (
                run(
                    f'aws acm describe-certificate --certificate-arn {state["cert_arn"]} --region {REGION}',
                    check=False
                ) or {}
            ).get("Certificate", {}).get("Status") == "ISSUED",
            timeout=300,
            interval=15,
        )
        if not cert_ready:
            print("  Certificate NOT yet validated. Continuing with remaining stages...")
            print("  Re-run 'deploy' after changing GoDaddy nameservers to complete HTTPS setup.")
            state["ssl_pending"] = True
            save_state(state)
            return

    # Create HTTPS listener
    if not state.get("https_listener_arn"):
        result = run(
            f'aws elbv2 create-listener --load-balancer-arn {state["alb_arn"]} '
            f'--protocol HTTPS --port 443 '
            f'--certificates CertificateArn={state["cert_arn"]} '
            f'--default-actions Type=forward,TargetGroupArn={state["tg_arn"]} '
            f'--region {REGION}'
        )
        if result:
            state["https_listener_arn"] = result["Listeners"][0]["ListenerArn"]
            save_state(state)
            print(f"  HTTPS Listener: port 443")

    # Only redirect HTTP to HTTPS if HTTPS listener exists
    if state.get("https_listener_arn"):
        run(
            f'aws elbv2 modify-listener --listener-arn {state["http_listener_arn"]} '
            f'--default-actions Type=redirect,RedirectConfig="{{Protocol=HTTPS,Port=443,StatusCode=HTTP_301}}" '
            f'--region {REGION}'
        )
        print("  HTTP -> HTTPS redirect enabled")
        state.pop("ssl_pending", None)
    else:
        print("  Skipping HTTP->HTTPS redirect (HTTPS listener not ready)")

    # Point domain to ALB via Route 53 alias
    alias_record = {
        "Changes": [{
            "Action": "UPSERT",
            "ResourceRecordSet": {
                "Name": domain,
                "Type": "A",
                "AliasTarget": {
                    "HostedZoneId": state["alb_hosted_zone"],
                    "DNSName": state["alb_dns"],
                    "EvaluateTargetHealth": True
                }
            }
        }]
    }
    ar_uri = write_tmp_json(alias_record)
    run(
        f"aws route53 change-resource-record-sets "
        f"--hosted-zone-id {state['hosted_zone_id']} "
        f"--change-batch {ar_uri}"
    )
    cleanup_tmp()
    print(f"  DNS: {domain} -> {state['alb_dns']}")

    state["proxy_domain"] = domain
    save_state(state)


# ── Stage 7: IAM Roles ──────────────────────────────────────────

def create_iam_roles(state):
    print("\n=== Stage 7: IAM Roles ===")

    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"Service": "ecs-tasks.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }]
    }
    trust_uri = write_tmp_json(trust_policy)

    # Execution Role (pull images, fetch secrets, write logs)
    if not state.get("execution_role_arn"):
        result = run(
            f"aws iam create-role --role-name {PROJECT}-ecs-execution "
            f"--assume-role-policy-document {trust_uri}"
        )
        if result:
            state["execution_role_arn"] = result["Role"]["Arn"]
        else:
            result = run(f"aws iam get-role --role-name {PROJECT}-ecs-execution")
            state["execution_role_arn"] = result["Role"]["Arn"]

        # Attach managed policy
        run(
            f'aws iam attach-role-policy --role-name {PROJECT}-ecs-execution '
            f'--policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy'
        )

        # Inline policy for Secrets Manager
        secrets_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": ["secretsmanager:GetSecretValue"],
                "Resource": f"arn:aws:secretsmanager:{REGION}:{ACCOUNT_ID}:secret:{PROJECT}/*"
            }]
        }
        sp_uri = write_tmp_json(secrets_policy)
        run(
            f"aws iam put-role-policy --role-name {PROJECT}-ecs-execution "
            f"--policy-name secrets-access --policy-document {sp_uri}"
        )
        print(f"  Execution Role: {state['execution_role_arn']}")
    else:
        print(f"  Execution Role already exists: {state['execution_role_arn']}")

    # Task Role (DynamoDB access for the app)
    if not state.get("task_role_arn"):
        trust_uri = write_tmp_json(trust_policy)
        result = run(
            f"aws iam create-role --role-name {PROJECT}-ecs-task "
            f"--assume-role-policy-document {trust_uri}"
        )
        if result:
            state["task_role_arn"] = result["Role"]["Arn"]
        else:
            result = run(f"aws iam get-role --role-name {PROJECT}-ecs-task")
            state["task_role_arn"] = result["Role"]["Arn"]

        # DynamoDB access
        dynamo_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": [
                    "dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:UpdateItem",
                    "dynamodb:DeleteItem", "dynamodb:Query", "dynamodb:Scan"
                ],
                "Resource": [
                    f"arn:aws:dynamodb:{REGION}:{ACCOUNT_ID}:table/VoiceAI_Platform",
                    f"arn:aws:dynamodb:{REGION}:{ACCOUNT_ID}:table/VoiceAI_Platform/index/*"
                ]
            }]
        }
        dp_uri = write_tmp_json(dynamo_policy)
        run(
            f"aws iam put-role-policy --role-name {PROJECT}-ecs-task "
            f"--policy-name dynamodb-access --policy-document {dp_uri}"
        )
        print(f"  Task Role: {state['task_role_arn']}")
    else:
        print(f"  Task Role already exists: {state['task_role_arn']}")

    cleanup_tmp()

    save_state(state)


# ── Stage 8: ECS Cluster + CloudWatch ────────────────────────────

def create_ecs_cluster(state):
    print("\n=== Stage 8: ECS Cluster + CloudWatch ===")

    if not state.get("cluster_arn"):
        result = run(
            f'aws ecs create-cluster --cluster-name {PROJECT}-cluster '
            f'--capacity-providers FARGATE '
            f'--default-capacity-provider-strategy capacityProvider=FARGATE,weight=1 '
            f'--region {REGION}'
        )
        state["cluster_arn"] = result["cluster"]["clusterArn"]
        print(f"  Cluster: {state['cluster_arn']}")
    else:
        print(f"  Cluster already exists")

    # CloudWatch Log Group
    run(f'aws logs create-log-group --log-group-name /ecs/{PROJECT} --region {REGION}', check=False)
    run(f'aws logs put-retention-policy --log-group-name /ecs/{PROJECT} --retention-in-days 30 --region {REGION}')
    print(f"  Log group: /ecs/{PROJECT} (30 day retention)")

    save_state(state)


# ── Stage 9: Task Definition ────────────────────────────────────

def register_task_definition(state):
    print("\n=== Stage 9: Task Definition ===")

    proxy_domain = state.get("proxy_domain", state.get("alb_dns", "PENDING"))
    secret_arn = state.get("secret_arn", "")

    task_def = {
        "family": PROJECT,
        "networkMode": "awsvpc",
        "requiresCompatibilities": ["FARGATE"],
        "cpu": TASK_CPU,
        "memory": TASK_MEMORY,
        "executionRoleArn": state["execution_role_arn"],
        "taskRoleArn": state["task_role_arn"],
        "containerDefinitions": [{
            "name": PROJECT,
            "image": f"{ECR_REPO}:latest",
            "portMappings": [{"containerPort": 7860, "protocol": "tcp"}],
            "essential": True,
            "environment": [
                {"name": "PROXY_DOMAIN", "value": proxy_domain},
                {"name": "AWS_DEFAULT_REGION", "value": REGION},
            ],
            "secrets": [
                {"name": "DEEPGRAM_API_KEY", "valueFrom": f"{secret_arn}:DEEPGRAM_API_KEY::"},
                {"name": "OPENAI_API_KEY", "valueFrom": f"{secret_arn}:OPENAI_API_KEY::"},
                {"name": "CARTESIA_API_KEY", "valueFrom": f"{secret_arn}:CARTESIA_API_KEY::"},
                {"name": "TWILIO_ACCOUNT_SID", "valueFrom": f"{secret_arn}:TWILIO_ACCOUNT_SID::"},
                {"name": "TWILIO_AUTH_TOKEN", "valueFrom": f"{secret_arn}:TWILIO_AUTH_TOKEN::"},
                {"name": "GOOGLE_CALENDAR_CREDENTIALS_JSON", "valueFrom": f"{secret_arn}:GOOGLE_CALENDAR_CREDENTIALS_JSON::"},
            ],
            "logConfiguration": {
                "logDriver": "awslogs",
                "options": {
                    "awslogs-group": f"/ecs/{PROJECT}",
                    "awslogs-region": REGION,
                    "awslogs-stream-prefix": "ecs"
                }
            },
            "healthCheck": {
                "command": ["CMD-SHELL", "curl -f http://localhost:7860/health || exit 1"],
                "interval": 30,
                "timeout": 10,
                "retries": 5,
                "startPeriod": 300
            }
        }]
    }

    # Write to temp file and register
    task_def_file = os.path.join(os.path.dirname(__file__), "task-definition.json")
    with open(task_def_file, "w") as f:
        json.dump(task_def, f, indent=2)

    result = run(
        f'aws ecs register-task-definition --cli-input-json file://{task_def_file} --region {REGION}'
    )
    if result:
        state["task_def_arn"] = result["taskDefinition"]["taskDefinitionArn"]
        state["task_def_revision"] = result["taskDefinition"]["revision"]
        print(f"  Task Definition: {PROJECT}:{state['task_def_revision']}")
    save_state(state)


# ── Stage 10: ECS Service ────────────────────────────────────────

def create_ecs_service(state):
    print("\n=== Stage 10: ECS Service ===")

    if state.get("service_created"):
        # Update existing service
        run(
            f'aws ecs update-service --cluster {PROJECT}-cluster '
            f'--service {PROJECT}-service '
            f'--task-definition {PROJECT} '
            f'--force-new-deployment '
            f'--region {REGION}'
        )
        print("  Service updated with new task definition")
        return

    result = run(
        f'aws ecs create-service --cluster {PROJECT}-cluster '
        f'--service-name {PROJECT}-service '
        f'--task-definition {PROJECT} '
        f'--desired-count {DESIRED_TASKS} '
        f'--launch-type FARGATE '
        f'--network-configuration "awsvpcConfiguration={{subnets=[{state["subnet_private_a"]},{state["subnet_private_b"]}],securityGroups=[{state["ecs_sg"]}],assignPublicIp=DISABLED}}" '
        f'--load-balancers "targetGroupArn={state["tg_arn"]},containerName={PROJECT},containerPort=7860" '
        f'--health-check-grace-period-seconds 360 '
        f'--deployment-configuration "maximumPercent=200,minimumHealthyPercent=100" '
        f'--enable-execute-command '
        f'--region {REGION}'
    )
    if result:
        state["service_created"] = True
        print(f"  Service created: {DESIRED_TASKS} tasks")
    save_state(state)


# ── Stage 11: Auto Scaling ──────────────────────────────────────

def setup_autoscaling(state):
    print("\n=== Stage 11: Auto Scaling ===")

    resource_id = f"service/{PROJECT}-cluster/{PROJECT}-service"

    run(
        f'aws application-autoscaling register-scalable-target '
        f'--service-namespace ecs '
        f'--scalable-dimension ecs:service:DesiredCount '
        f'--resource-id {resource_id} '
        f'--min-capacity {MIN_TASKS} --max-capacity {MAX_TASKS} '
        f'--region {REGION}'
    )

    scaling_config = {
        "TargetValue": 60.0,
        "PredefinedMetricSpecification": {
            "PredefinedMetricType": "ECSServiceAverageCPUUtilization"
        },
        "ScaleInCooldown": 300,
        "ScaleOutCooldown": 60
    }
    sc_uri = write_tmp_json(scaling_config)

    run(
        f"aws application-autoscaling put-scaling-policy "
        f"--service-namespace ecs "
        f"--scalable-dimension ecs:service:DesiredCount "
        f"--resource-id {resource_id} "
        f"--policy-name {PROJECT}-cpu-scaling "
        f"--policy-type TargetTrackingScaling "
        f"--target-tracking-scaling-policy-configuration {sc_uri} "
        f"--region {REGION}"
    )
    cleanup_tmp()
    print(f"  Auto scaling: min={MIN_TASKS}, max={MAX_TASKS}, target=60% CPU")


# ── Stage 11b: SES Email Infrastructure ──────────────────────────


def setup_email_infrastructure(state):
    """Set up AWS SES, SNS, and MX records for inbound email booking.

    Creates:
    1. SES domain identity verification for prodvoice.link
    2. DKIM records in Route 53
    3. MX record (wildcard *.prodvoice.link -> SES inbound)
    4. SNS topic for inbound email notifications
    5. SES Receipt Rule Set + Rule (catch *.prodvoice.link -> SNS)
    6. IAM policy for SES sending on the ECS task role
    7. SNS HTTPS subscription to /webhooks/email endpoint
    """
    print("\n=== Stage 11b: SES Email Infrastructure ===")

    hosted_zone_id = state.get("hosted_zone_id")
    if not hosted_zone_id:
        print("  Skipping — no hosted zone. Run full deploy first.")
        return

    proxy_domain = state.get("proxy_domain")
    if not proxy_domain:
        print("  Skipping — no domain configured. Run full deploy first.")
        return

    # ── 1. Verify SES domain identity ──
    if not state.get("ses_domain_verified"):
        print("  Verifying SES domain identity...")
        result = run(
            f'aws ses verify-domain-identity --domain {DOMAIN} --region {REGION}'
        )
        if result:
            verification_token = result["VerificationToken"]
            state["ses_verification_token"] = verification_token
            print(f"  Verification token: {verification_token}")

            # Add TXT record for domain verification
            change_batch = {
                "Changes": [{
                    "Action": "UPSERT",
                    "ResourceRecordSet": {
                        "Name": f"_amazonses.{DOMAIN}",
                        "Type": "TXT",
                        "TTL": 300,
                        "ResourceRecords": [{"Value": f'"{verification_token}"'}]
                    }
                }]
            }
            cb_uri = write_tmp_json(change_batch)
            run(
                f"aws route53 change-resource-record-sets "
                f"--hosted-zone-id {hosted_zone_id} "
                f"--change-batch {cb_uri}"
            )
            print(f"  TXT record added: _amazonses.{DOMAIN}")
            state["ses_domain_verified"] = True
            save_state(state)
        cleanup_tmp()

    # ── 2. Set up DKIM ──
    if not state.get("ses_dkim_configured"):
        print("  Setting up DKIM...")
        result = run(
            f'aws ses verify-domain-dkim --domain {DOMAIN} --region {REGION}'
        )
        if result:
            dkim_tokens = result.get("DkimTokens", [])
            state["ses_dkim_tokens"] = dkim_tokens

            # Add DKIM CNAME records
            changes = []
            for token in dkim_tokens:
                changes.append({
                    "Action": "UPSERT",
                    "ResourceRecordSet": {
                        "Name": f"{token}._domainkey.{DOMAIN}",
                        "Type": "CNAME",
                        "TTL": 300,
                        "ResourceRecords": [{"Value": f"{token}.dkim.amazonses.com"}]
                    }
                })

            if changes:
                change_batch = {"Changes": changes}
                cb_uri = write_tmp_json(change_batch)
                run(
                    f"aws route53 change-resource-record-sets "
                    f"--hosted-zone-id {hosted_zone_id} "
                    f"--change-batch {cb_uri}"
                )
                print(f"  {len(dkim_tokens)} DKIM CNAME records added")
                state["ses_dkim_configured"] = True
                save_state(state)
            cleanup_tmp()

    # ── 3. MX record for inbound email ──
    # Wildcard MX record: *.prodvoice.link -> SES inbound SMTP
    if not state.get("ses_mx_record"):
        print("  Adding MX record for inbound email...")

        # SES inbound SMTP endpoint for us-west-2
        ses_inbound = "inbound-smtp.us-west-2.amazonaws.com"

        change_batch = {
            "Changes": [{
                "Action": "UPSERT",
                "ResourceRecordSet": {
                    "Name": f"*.{DOMAIN}",
                    "Type": "MX",
                    "TTL": 300,
                    "ResourceRecords": [{"Value": f"10 {ses_inbound}"}]
                }
            }]
        }
        cb_uri = write_tmp_json(change_batch)
        run(
            f"aws route53 change-resource-record-sets "
            f"--hosted-zone-id {hosted_zone_id} "
            f"--change-batch {cb_uri}"
        )
        print(f"  MX record: *.{DOMAIN} -> 10 {ses_inbound}")
        state["ses_mx_record"] = True
        save_state(state)
        cleanup_tmp()

    # ── 4. SNS topic for inbound email ──
    if not state.get("sns_email_topic_arn"):
        print("  Creating SNS topic for inbound email...")
        result = run(
            f'aws sns create-topic --name {PROJECT}-inbound-email --region {REGION}'
        )
        if result:
            state["sns_email_topic_arn"] = result["TopicArn"]
            print(f"  SNS topic: {state['sns_email_topic_arn']}")

            # Set topic policy to allow SES to publish
            topic_arn = state["sns_email_topic_arn"]
            sns_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "AllowSESPublish",
                        "Effect": "Allow",
                        "Principal": {"Service": "ses.amazonaws.com"},
                        "Action": "SNS:Publish",
                        "Resource": topic_arn,
                        "Condition": {
                            "StringEquals": {
                                "AWS:SourceAccount": ACCOUNT_ID
                            }
                        }
                    },
                    {
                        "Sid": "DefaultPolicy",
                        "Effect": "Allow",
                        "Principal": {"AWS": "*"},
                        "Action": [
                            "SNS:Subscribe", "SNS:ListSubscriptionsByTopic",
                            "SNS:GetTopicAttributes", "SNS:SetTopicAttributes",
                            "SNS:AddPermission", "SNS:RemovePermission",
                            "SNS:DeleteTopic", "SNS:Publish"
                        ],
                        "Resource": topic_arn,
                        "Condition": {
                            "StringEquals": {
                                "AWS:SourceOwner": ACCOUNT_ID
                            }
                        }
                    }
                ]
            }
            policy_json = json.dumps(sns_policy).replace('"', '\\"')
            run(
                f'aws sns set-topic-attributes '
                f'--topic-arn {topic_arn} '
                f'--attribute-name Policy '
                f"--attribute-value \"{policy_json}\" "
                f'--region {REGION}',
                check=False
            )
            print(f"  SNS topic policy updated (SES publish allowed)")

            save_state(state)
    else:
        print(f"  SNS topic already exists: {state['sns_email_topic_arn']}")

    # ── 5. SES Receipt Rule Set + Rule ──
    if not state.get("ses_receipt_rule_created"):
        print("  Creating SES Receipt Rule Set...")

        # Create rule set (or use existing)
        rule_set_name = f"{PROJECT}-inbound-rules"
        run(
            f'aws ses create-receipt-rule-set --rule-set-name {rule_set_name} --region {REGION}',
            check=False  # May already exist
        )

        # Create receipt rule that matches *.prodvoice.link and forwards to SNS
        rule = {
            "Name": f"{PROJECT}-email-to-sns",
            "Enabled": True,
            "TlsPolicy": "Optional",
            "Recipients": [f".{DOMAIN}"],
            "Actions": [{
                "SNSAction": {
                    "TopicArn": state["sns_email_topic_arn"],
                    "Encoding": "UTF-8"
                }
            }],
            "ScanEnabled": True
        }
        rule_uri = write_tmp_json(rule)
        run(
            f"aws ses create-receipt-rule "
            f"--rule-set-name {rule_set_name} "
            f"--rule {rule_uri} "
            f"--region {REGION}",
            check=False  # May already exist
        )

        # Activate the rule set
        run(
            f'aws ses set-active-receipt-rule-set --rule-set-name {rule_set_name} --region {REGION}',
            check=False
        )

        print(f"  Receipt rule: *.{DOMAIN} -> SNS topic")
        state["ses_receipt_rule_created"] = True
        state["ses_rule_set_name"] = rule_set_name
        save_state(state)
        cleanup_tmp()

    # ── 6. IAM policy for SES sending ──
    if not state.get("ses_iam_policy_added"):
        print("  Adding SES send permissions to ECS task role...")

        ses_policy = {
            "Version": "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": [
                    "ses:SendEmail",
                    "ses:SendRawEmail"
                ],
                "Resource": "*",
                "Condition": {
                    "StringLike": {
                        "ses:FromAddress": f"*@*.{DOMAIN}"
                    }
                }
            }]
        }
        sp_uri = write_tmp_json(ses_policy)
        run(
            f"aws iam put-role-policy --role-name {PROJECT}-ecs-task "
            f"--policy-name ses-send-access --policy-document {sp_uri}"
        )
        print(f"  SES send policy added to {PROJECT}-ecs-task role")
        state["ses_iam_policy_added"] = True
        save_state(state)
        cleanup_tmp()

    # ── 7. SNS subscription to webhook endpoint ──
    if not state.get("sns_email_subscription_arn"):
        print("  Subscribing SNS to email webhook endpoint...")
        webhook_url = f"https://{proxy_domain}/webhooks/email"
        result = run(
            f'aws sns subscribe '
            f'--topic-arn {state["sns_email_topic_arn"]} '
            f'--protocol https '
            f'--notification-endpoint {webhook_url} '
            f'--region {REGION}'
        )
        if result:
            state["sns_email_subscription_arn"] = result.get("SubscriptionArn", "pending")
            print(f"  SNS subscription: {webhook_url}")
            print(f"  Status: {state['sns_email_subscription_arn']}")
            print(f"  NOTE: The app must be running to confirm the subscription.")
            print(f"        SNS will POST a SubscriptionConfirmation that the app auto-confirms.")
            save_state(state)
    else:
        print(f"  SNS subscription already exists: {state['sns_email_subscription_arn']}")

    print("\n  Email infrastructure setup complete!")
    print(f"  Inbound emails to: *@*.{DOMAIN}")
    print(f"  Webhook: https://{proxy_domain}/webhooks/email")
    print(f"  SNS topic: {state.get('sns_email_topic_arn', 'N/A')}")

    # Check SES domain verification status
    result = run(
        f'aws ses get-identity-verification-attributes '
        f'--identities {DOMAIN} --region {REGION}',
        check=False
    )
    if result:
        attrs = result.get("VerificationAttributes", {}).get(DOMAIN, {})
        status = attrs.get("VerificationStatus", "unknown")
        print(f"  SES domain verification: {status}")
        if status != "Success":
            print(f"  NOTE: DNS propagation may take 5-30 minutes. Re-run deploy to check.")

    print()


# ── Stage 12: Build & Push Docker Image ──────────────────────────

def build_and_push(state):
    print("\n=== Stage 12: Build & Push Docker Image ===")

    project_dir = os.path.dirname(__file__)

    # Check Docker is running
    docker_check = subprocess.run("docker ps", shell=True, capture_output=True, text=True)
    if docker_check.returncode != 0:
        print("  ERROR: Docker Desktop is not running!")
        print("  Please start Docker Desktop and re-run 'deploy'.")
        sys.exit(1)

    # Authenticate Docker to ECR
    print("  Authenticating Docker to ECR...")
    run(
        f'aws ecr get-login-password --region {REGION} | '
        f'docker login --username AWS --password-stdin {ACCOUNT_ID}.dkr.ecr.{REGION}.amazonaws.com',
        capture=False
    )

    # Build
    print("  Building Docker image (this may take a few minutes)...")
    run(
        f'docker build --platform linux/amd64 -t {PROJECT}:latest "{project_dir}"',
        capture=False
    )

    # Tag & Push
    print("  Pushing to ECR...")
    run(f'docker tag {PROJECT}:latest {ECR_REPO}:latest', capture=False)
    run(f'docker push {ECR_REPO}:latest', capture=False)

    timestamp = int(time.time())
    run(f'docker tag {PROJECT}:latest {ECR_REPO}:{timestamp}', capture=False)
    run(f'docker push {ECR_REPO}:{timestamp}', capture=False)

    print(f"  Pushed: {ECR_REPO}:latest and {ECR_REPO}:{timestamp}")


# ── Stage 13: Update Twilio Webhook ─────────────────────────────

def update_twilio_webhook(state):
    print("\n=== Stage 13: Update Twilio Webhook ===")

    proxy_domain = state.get("proxy_domain")
    if not proxy_domain:
        print("  Skipping — no domain configured yet")
        return

    with open(SECRETS_FILE) as f:
        secrets = json.load(f)

    webhook_url = f"https://{proxy_domain}/"
    print(f"  Setting webhook for {TWILIO_PHONE_SID} to: {webhook_url}")

    result = run(
        f'curl -s -X POST "https://api.twilio.com/2010-04-01/Accounts/{secrets["TWILIO_ACCOUNT_SID"]}/IncomingPhoneNumbers/{TWILIO_PHONE_SID}.json" '
        f'-u "{secrets["TWILIO_ACCOUNT_SID"]}:{secrets["TWILIO_AUTH_TOKEN"]}" '
        f'-d "VoiceUrl={webhook_url}" -d "VoiceMethod=POST"',
        check=False
    )
    if result and isinstance(result, dict) and result.get("voice_url"):
        print(f"  Twilio webhook updated: {result['voice_url']}")
    else:
        print(f"  Twilio update sent (check Twilio console to verify)")


# ── Stage 14: Verification ──────────────────────────────────────

def verify_deployment(state):
    print("\n=== Stage 14: Verification ===")

    # Check ECS service
    result = run(
        f'aws ecs describe-services --cluster {PROJECT}-cluster '
        f'--services {PROJECT}-service --region {REGION}'
    )
    if result:
        svc = result["services"][0]
        print(f"  Service status: {svc['status']}")
        print(f"  Running tasks: {svc['runningCount']}/{svc['desiredCount']}")

    # Check target health
    if state.get("tg_arn"):
        result = run(
            f'aws elbv2 describe-target-health --target-group-arn {state["tg_arn"]} --region {REGION}'
        )
        if result:
            for target in result.get("TargetHealthDescriptions", []):
                health = target["TargetHealth"]["State"]
                target_id = target["Target"]["Id"]
                print(f"  Target {target_id}: {health}")

    # Health check
    proxy_domain = state.get("proxy_domain", state.get("alb_dns"))
    if proxy_domain:
        protocol = "https" if state.get("proxy_domain") else "http"
        print(f"\n  Health check URL: {protocol}://{proxy_domain}/health")
        result = run(f'curl -s {protocol}://{proxy_domain}/health', check=False)
        if result:
            print(f"  Response: {result}")

    print("\n  ==============================")
    print(f"  ALB DNS:   {state.get('alb_dns', 'N/A')}")
    print(f"  Domain:    {state.get('proxy_domain', 'Not configured')}")
    print(f"  Webhook:   https://{state.get('proxy_domain', state.get('alb_dns', 'N/A'))}/")
    print("  ==============================")


# ── Status Command ───────────────────────────────────────────────

def show_status():
    state = load_state()
    print("\n=== ProdVoiceAI Deployment Status ===\n")

    if not state:
        print("  No deployment found. Run: python deploy_aws.py deploy")
        return

    verify_deployment(state)


# ── Redeploy Command ────────────────────────────────────────────

def redeploy():
    state = load_state()
    if not state.get("service_created"):
        print("  No existing deployment. Run: python deploy_aws.py deploy")
        return

    build_and_push(state)
    register_task_definition(state)
    create_ecs_service(state)  # Will update existing
    print("\n  Redeployment triggered. Tasks will roll out over ~5-10 minutes.")


# ── Deploy Command ───────────────────────────────────────────────

def deploy():
    state = load_state()
    print("=== ProdVoiceAI AWS Deployment ===")
    print(f"  Region: {REGION}")
    print(f"  Account: {ACCOUNT_ID}")

    create_ecr(state)
    create_secrets(state)
    create_vpc(state)
    create_security_groups(state)
    create_alb(state)
    create_domain_and_ssl(state)
    create_iam_roles(state)
    create_ecs_cluster(state)
    build_and_push(state)
    register_task_definition(state)
    create_ecs_service(state)
    setup_autoscaling(state)

    print("\n  Waiting for ECS tasks to start (this takes ~5 minutes for ML model loading)...")
    wait_for(
        "ECS tasks running",
        lambda: (
            run(
                f'aws ecs describe-services --cluster {PROJECT}-cluster '
                f'--services {PROJECT}-service --region {REGION}',
                check=False
            ) or {}
        ).get("services", [{}])[0].get("runningCount", 0) >= 1,
        timeout=600,
        interval=20,
    )

    setup_email_infrastructure(state)
    update_twilio_webhook(state)
    verify_deployment(state)

    print("\n=== Deployment Complete! ===")
    domain = state.get("proxy_domain", state.get("alb_dns"))
    print(f"  Your app is live at: https://{domain}/")
    print(f"  Call +14259529066 to test!")
    print(f"  Email: book@elitecuts.{DOMAIN} (after seeding tenant)")


# ── Teardown Command ────────────────────────────────────────────

def teardown():
    state = load_state()
    if not state:
        print("No deployment state found.")
        return

    print("=== Tearing down ProdVoiceAI AWS resources ===")
    print("  WARNING: This will delete ALL resources.")
    confirm = input("  Type 'yes' to confirm: ").strip()
    if confirm != "yes":
        print("  Aborted.")
        return

    # Delete in reverse dependency order

    # 0. Email infrastructure (SES, SNS, MX)
    if state.get("sns_email_subscription_arn"):
        sub_arn = state["sns_email_subscription_arn"]
        if sub_arn != "pending" and sub_arn.startswith("arn:"):
            run(f'aws sns unsubscribe --subscription-arn {sub_arn} --region {REGION}', check=False)
    if state.get("ses_rule_set_name"):
        run(f'aws ses set-active-receipt-rule-set --region {REGION}', check=False)
        run(
            f'aws ses delete-receipt-rule '
            f'--rule-set-name {state["ses_rule_set_name"]} '
            f'--rule-name {PROJECT}-email-to-sns --region {REGION}',
            check=False
        )
        run(
            f'aws ses delete-receipt-rule-set '
            f'--rule-set-name {state["ses_rule_set_name"]} --region {REGION}',
            check=False
        )
    if state.get("sns_email_topic_arn"):
        run(f'aws sns delete-topic --topic-arn {state["sns_email_topic_arn"]} --region {REGION}', check=False)
    if state.get("ses_iam_policy_added"):
        run(
            f'aws iam delete-role-policy --role-name {PROJECT}-ecs-task '
            f'--policy-name ses-send-access',
            check=False
        )

    # 1. Auto scaling
    resource_id = f"service/{PROJECT}-cluster/{PROJECT}-service"
    run(
        f'aws application-autoscaling deregister-scalable-target '
        f'--service-namespace ecs --scalable-dimension ecs:service:DesiredCount '
        f'--resource-id {resource_id} --region {REGION}',
        check=False
    )

    # 2. ECS Service
    run(
        f'aws ecs update-service --cluster {PROJECT}-cluster '
        f'--service {PROJECT}-service --desired-count 0 --region {REGION}',
        check=False
    )
    time.sleep(5)
    run(
        f'aws ecs delete-service --cluster {PROJECT}-cluster '
        f'--service {PROJECT}-service --force --region {REGION}',
        check=False
    )

    # 3. ECS Cluster
    run(f'aws ecs delete-cluster --cluster {PROJECT}-cluster --region {REGION}', check=False)

    # 4. ALB listeners, target group, load balancer
    if state.get("https_listener_arn"):
        run(f'aws elbv2 delete-listener --listener-arn {state["https_listener_arn"]} --region {REGION}', check=False)
    if state.get("http_listener_arn"):
        run(f'aws elbv2 delete-listener --listener-arn {state["http_listener_arn"]} --region {REGION}', check=False)
    if state.get("alb_arn"):
        run(f'aws elbv2 delete-load-balancer --load-balancer-arn {state["alb_arn"]} --region {REGION}', check=False)
    time.sleep(5)
    if state.get("tg_arn"):
        run(f'aws elbv2 delete-target-group --target-group-arn {state["tg_arn"]} --region {REGION}', check=False)

    # 5. NAT Gateway
    if state.get("nat_gw_id"):
        run(f'aws ec2 delete-nat-gateway --nat-gateway-id {state["nat_gw_id"]} --region {REGION}', check=False)
        print("  Waiting for NAT Gateway deletion...")
        time.sleep(30)

    # 6. Elastic IP
    if state.get("eip_alloc"):
        run(f'aws ec2 release-address --allocation-id {state["eip_alloc"]} --region {REGION}', check=False)

    # 7. Security Groups
    for sg_key in ["ecs_sg", "alb_sg"]:
        if state.get(sg_key):
            run(f'aws ec2 delete-security-group --group-id {state[sg_key]} --region {REGION}', check=False)

    # 8. Subnets
    for key in ["subnet_private_b", "subnet_private_a", "subnet_public_b", "subnet_public_a"]:
        if state.get(key):
            run(f'aws ec2 delete-subnet --subnet-id {state[key]} --region {REGION}', check=False)

    # 9. Route tables
    for rt_key in ["private_rt", "public_rt"]:
        if state.get(rt_key):
            # Disassociate first
            result = run(
                f'aws ec2 describe-route-tables --route-table-ids {state[rt_key]} --region {REGION}',
                check=False
            )
            if result:
                for assoc in result.get("RouteTables", [{}])[0].get("Associations", []):
                    if not assoc.get("Main", False):
                        run(f'aws ec2 disassociate-route-table --association-id {assoc["RouteTableAssociationId"]}', check=False)
            run(f'aws ec2 delete-route-table --route-table-id {state[rt_key]} --region {REGION}', check=False)

    # 10. IGW
    if state.get("igw_id") and state.get("vpc_id"):
        run(f'aws ec2 detach-internet-gateway --internet-gateway-id {state["igw_id"]} --vpc-id {state["vpc_id"]}', check=False)
        run(f'aws ec2 delete-internet-gateway --internet-gateway-id {state["igw_id"]} --region {REGION}', check=False)

    # 11. VPC
    if state.get("vpc_id"):
        run(f'aws ec2 delete-vpc --vpc-id {state["vpc_id"]} --region {REGION}', check=False)

    # 12. IAM Roles
    for role_name in [f"{PROJECT}-ecs-execution", f"{PROJECT}-ecs-task"]:
        run(f'aws iam delete-role-policy --role-name {role_name} --policy-name secrets-access', check=False)
        run(f'aws iam delete-role-policy --role-name {role_name} --policy-name dynamodb-access', check=False)
        run(
            f'aws iam detach-role-policy --role-name {role_name} '
            f'--policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy',
            check=False
        )
        run(f'aws iam delete-role --role-name {role_name}', check=False)

    # 13. CloudWatch
    run(f'aws logs delete-log-group --log-group-name /ecs/{PROJECT} --region {REGION}', check=False)

    # 14. ECR
    run(f'aws ecr delete-repository --repository-name {PROJECT} --force --region {REGION}', check=False)

    # Don't delete secrets (they're expensive to recreate and have a recovery window)
    print("  NOTE: Secrets Manager secret NOT deleted (has recovery window). Delete manually if needed.")

    # Remove state file
    if os.path.exists(STATE_FILE):
        os.remove(STATE_FILE)

    print("\n=== Teardown complete ===")


# ── Entry Point ──────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ProdVoiceAI AWS Deployment")
    parser.add_argument(
        "command",
        choices=["deploy", "status", "redeploy", "teardown", "setup-email"],
        help="deploy: full setup | status: check health | redeploy: rebuild+push | teardown: delete all | setup-email: SES/SNS/MX only"
    )
    args = parser.parse_args()

    if args.command == "deploy":
        deploy()
    elif args.command == "status":
        show_status()
    elif args.command == "redeploy":
        redeploy()
    elif args.command == "teardown":
        teardown()
    elif args.command == "setup-email":
        state = load_state()
        if not state.get("hosted_zone_id"):
            print("  ERROR: No hosted zone found. Run full deploy first.")
            sys.exit(1)
        setup_email_infrastructure(state)
