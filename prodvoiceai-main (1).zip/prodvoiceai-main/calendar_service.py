"""Google Calendar sync service.

Syncs confirmed appointments to Google Calendar so barbers/staff can see
bookings on their phone or desktop calendar in real-time.

Uses a Google Cloud service account (no OAuth consent screen needed).
The service account must be shared with the target Google Calendar.

Environment:
    GOOGLE_CALENDAR_CREDENTIALS_JSON  Base64-encoded service account JSON key

Calendar sync is best-effort: failures are logged but never block bookings.
"""

import asyncio
import base64
import json
import os
from datetime import datetime, timedelta

from loguru import logger

# Lazy-loaded Google API client
_calendar_service = None


def _get_calendar_service():
    """Build and cache the Google Calendar API client."""
    global _calendar_service
    if _calendar_service is not None:
        return _calendar_service

    creds_b64 = os.getenv("GOOGLE_CALENDAR_CREDENTIALS_JSON", "")
    if not creds_b64:
        logger.warning("GOOGLE_CALENDAR_CREDENTIALS_JSON not set — calendar sync disabled")
        return None

    try:
        from google.oauth2 import service_account
        from googleapiclient.discovery import build

        creds_json = base64.b64decode(creds_b64)
        creds_info = json.loads(creds_json)
        credentials = service_account.Credentials.from_service_account_info(
            creds_info,
            scopes=["https://www.googleapis.com/auth/calendar"],
        )
        _calendar_service = build("calendar", "v3", credentials=credentials)
        logger.info("Google Calendar API client initialized")
        return _calendar_service
    except Exception as e:
        logger.error(f"Failed to initialize Google Calendar client: {e}")
        return None


def _sync_booking_to_calendar_sync(
    calendar_id: str,
    business_name: str,
    timezone: str,
    appointment: dict,
) -> str | None:
    """Create a Google Calendar event for a booked appointment.

    Args:
        calendar_id: Google Calendar ID to create the event in
        business_name: Business name for the event description
        timezone: IANA timezone (e.g. "America/Los_Angeles")
        appointment: Dict with keys: customer_name, service, staff, date,
                     time, end_time, phone, price, duration_minutes

    Returns:
        The Google Calendar event ID, or None if sync failed.
    """
    service = _get_calendar_service()
    if not service:
        return None

    if not calendar_id:
        logger.debug("No google_calendar_id configured — skipping calendar sync")
        return None

    date = appointment["date"]
    start_time = appointment["time"]
    end_time = appointment["end_time"]
    customer = appointment["customer_name"]
    staff = appointment["staff"]
    svc_name = appointment["service"]
    price = appointment.get("price", 0)
    phone = appointment.get("phone", "")

    event = {
        "summary": f"{svc_name} — {customer}",
        "description": (
            f"Customer: {customer}\n"
            f"Phone: {phone}\n"
            f"Service: {svc_name} (${price:.0f})\n"
            f"Staff: {staff}\n"
            f"\nBooked via {business_name}"
        ),
        "start": {
            "dateTime": f"{date}T{start_time}:00",
            "timeZone": timezone,
        },
        "end": {
            "dateTime": f"{date}T{end_time}:00",
            "timeZone": timezone,
        },
        "reminders": {
            "useDefault": False,
            "overrides": [
                {"method": "popup", "minutes": 30},
            ],
        },
    }

    try:
        result = service.events().insert(
            calendarId=calendar_id, body=event
        ).execute()
        event_id = result["id"]
        logger.info(f"Calendar event created: {event_id} ({svc_name} for {customer})")
        return event_id
    except Exception as e:
        logger.error(f"Failed to create calendar event: {e}")
        return None


def _delete_calendar_event_sync(calendar_id: str, event_id: str) -> bool:
    """Delete a Google Calendar event (on appointment cancellation).

    Returns True if deleted, False if failed or not found.
    """
    service = _get_calendar_service()
    if not service:
        return False

    if not calendar_id or not event_id:
        return False

    try:
        service.events().delete(
            calendarId=calendar_id, eventId=event_id
        ).execute()
        logger.info(f"Calendar event deleted: {event_id}")
        return True
    except Exception as e:
        logger.error(f"Failed to delete calendar event {event_id}: {e}")
        return False


# ── Public async API ──────────────────────────────────────────────────


async def sync_booking_to_calendar(
    calendar_id: str,
    business_name: str,
    timezone: str,
    appointment: dict,
) -> str | None:
    """Create a calendar event for a booking. Returns event_id or None."""
    return await asyncio.to_thread(
        _sync_booking_to_calendar_sync,
        calendar_id,
        business_name,
        timezone,
        appointment,
    )


async def delete_calendar_event(calendar_id: str, event_id: str) -> bool:
    """Delete a calendar event on cancellation."""
    return await asyncio.to_thread(
        _delete_calendar_event_sync, calendar_id, event_id
    )
