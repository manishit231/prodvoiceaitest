"""Multi-tenant Voice AI Platform — FastAPI application.

Custom FastAPI app that replaces pipecat's built-in runner with tenant-aware
call routing. When Twilio calls the webhook, we look up the tenant by the
called phone number, load their config, and build a dynamic bot pipeline.

Run with:
    uv run app.py                           # browser mode (WebRTC)
    uv run app.py --twilio --proxy DOMAIN   # phone mode (Twilio)

Architecture:
    Twilio POST /  →  look up tenant by To number  →  TwiML with tenant_id param
    Twilio WS /ws  →  extract tenant_id  →  load config  →  build pipeline  →  handle call
"""

import argparse
import asyncio
import os
import sys
from datetime import datetime
from urllib.parse import parse_qs, urlparse

from dotenv import load_dotenv
from loguru import logger

# ── Startup banner ──────────────────────────────────────────────────

print("=" * 50)
print("  VoiceAI Platform — Multi-Tenant Voice AI")
print("=" * 50)
print()
print("Loading models and imports (may take ~20 seconds on first run)")
print()

# ── Pre-load heavy ML models ───────────────────────────────────────

logger.info("Loading Local Smart Turn Analyzer V3...")
from pipecat.audio.turn.smart_turn.local_smart_turn_v3 import LocalSmartTurnAnalyzerV3

logger.info("Local Smart Turn Analyzer V3 loaded")
logger.info("Loading Silero VAD model...")
from pipecat.audio.vad.silero import SileroVADAnalyzer

logger.info("Silero VAD model loaded")

# ── Import everything else ──────────────────────────────────────────

from fastapi import FastAPI, Request, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn

from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.frames.frames import LLMRunFrame, EndTaskFrame
from pipecat.processors.frame_processor import FrameDirection
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import PipelineRunner
from pipecat.pipeline.task import PipelineParams, PipelineTask
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)
from pipecat.runner.utils import parse_telephony_websocket, _create_telephony_transport
from pipecat.services.cartesia.tts import CartesiaTTSService
from pipecat.services.deepgram.stt import DeepgramSTTService
from pipecat.services.llm_service import FunctionCallParams
from pipecat.services.openai.llm import OpenAILLMService
from pipecat.transports.websocket.fastapi import FastAPIWebsocketParams
from pipecat.turns.user_stop.turn_analyzer_user_turn_stop_strategy import (
    TurnAnalyzerUserTurnStopStrategy,
)
from pipecat.turns.user_turn_strategies import UserTurnStrategies

import appointment_service
import bot_factory
import tenant_service
from tenant_service import TenantConfig
from channels.sms import handle_sms_webhook
from channels.web import handle_chat_websocket
from channels.email import handle_email_webhook

logger.info("All components loaded successfully!")

load_dotenv(override=True)

# ── CLI argument parsing ────────────────────────────────────────────


def parse_args():
    parser = argparse.ArgumentParser(description="VoiceAI Platform")
    parser.add_argument("--host", default="0.0.0.0", help="Server host")
    parser.add_argument("--port", type=int, default=7860, help="Server port")
    parser.add_argument(
        "--twilio", action="store_true", help="Enable Twilio phone mode"
    )
    parser.add_argument(
        "--proxy", type=str, help="Public proxy domain (ngrok or ALB)"
    )
    return parser.parse_args()


# ── FastAPI app ─────────────────────────────────────────────────────

app = FastAPI(title="VoiceAI Platform")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Static files (chat widget) ────────────────────────────────────

import os as _os

_static_dir = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "static")
if _os.path.isdir(_static_dir):
    app.mount("/static", StaticFiles(directory=_static_dir), name="static")
    logger.info(f"Static files mounted from {_static_dir}")


# ── Health check ────────────────────────────────────────────────────


@app.get("/health")
async def health():
    return {"status": "healthy", "service": "voiceai-platform"}


# ── Twilio webhook — POST / ────────────────────────────────────────
# Twilio calls this when a phone call comes in.
# We look up the tenant by the To phone number and return TwiML
# that connects the audio to our WebSocket with the tenant_id.


@app.post("/")
async def twilio_webhook(request: Request):
    """Handle incoming Twilio call — route to correct tenant."""
    # Parse Twilio's form-encoded POST body
    form = await request.form()
    to_number = form.get("To", "")
    from_number = form.get("From", "")
    call_sid = form.get("CallSid", "")

    logger.info(f"Incoming call: To={to_number}, From={from_number}, CallSid={call_sid}")

    # Look up tenant by the called phone number
    tenant_id = await tenant_service.lookup_tenant_by_phone(to_number)

    if not tenant_id:
        logger.error(f"No tenant found for phone number: {to_number}")
        # Return TwiML that says sorry and hangs up
        xml = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say>Sorry, this number is not configured. Goodbye.</Say>
    <Hangup/>
</Response>"""
        return HTMLResponse(content=xml, media_type="application/xml")

    # Get the proxy domain from environment or CLI args
    proxy = os.getenv("PROXY_DOMAIN", "localhost:7860")

    # Return TwiML that connects to WebSocket with tenant_id as custom parameter
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Connect>
        <Stream url="wss://{proxy}/ws">
            <Parameter name="tenant_id" value="{tenant_id}" />
            <Parameter name="from_number" value="{from_number}" />
        </Stream>
    </Connect>
    <Pause length="40"/>
</Response>"""

    logger.info(f"Routing call to tenant: {tenant_id} via wss://{proxy}/ws")
    return HTMLResponse(content=xml, media_type="application/xml")


# ── SMS webhook — POST /webhooks/sms ─────────────────────────────────
# Twilio calls this when an SMS is received.


@app.post("/webhooks/sms")
async def sms_webhook(request: Request):
    """Handle incoming Twilio SMS."""
    return await handle_sms_webhook(request)


# ── Email webhook — POST /webhooks/email ──────────────────────────────
# AWS SNS calls this when an email is received via SES.


@app.post("/webhooks/email")
async def email_webhook(request: Request):
    """Handle incoming email via AWS SES/SNS."""
    return await handle_email_webhook(request)


# ── Booking Page API — /api/booking + /book ─────────────────────────
# REST endpoints for the public Calendly-style booking page.
# These bypass the AI layer — the UI itself handles the booking flow.


class BookingRequest(BaseModel):
    customer_name: str
    customer_phone: str
    service: str
    date: str
    time_slot: str
    staff_name: str


@app.get("/book/{tenant_id}")
async def booking_page(tenant_id: str):
    """Serve the public booking page at a clean URL."""
    book_path = os.path.join(_static_dir, "book.html")
    if not os.path.isfile(book_path):
        return JSONResponse(status_code=404, content={"error": "Booking page not available"})
    return FileResponse(path=book_path, media_type="text/html")


@app.get("/api/booking/{tenant_id}/info")
async def booking_info(tenant_id: str):
    """Return business info, services, and staff for the booking page."""
    config = await tenant_service.load_tenant_config(tenant_id)
    if not config:
        return JSONResponse(status_code=404, content={"error": "Business not found"})
    if "booking_page" not in config.enabled_channels:
        return JSONResponse(status_code=403, content={"error": "Online booking is not enabled for this business"})

    services = await appointment_service.get_services(config)
    staff = await appointment_service.get_staff(config)

    return {
        "business_name": config.business_name,
        "business_type": config.business_type,
        "timezone": config.timezone,
        "hours": config.hours,
        "services": services["services"],
        "staff": staff["staff"],
        "slot_duration_minutes": config.slot_duration_minutes,
    }


@app.get("/api/booking/{tenant_id}/availability")
async def booking_availability(tenant_id: str, date: str, staff_name: str):
    """Check available time slots for a date and staff member."""
    config = await tenant_service.load_tenant_config(tenant_id)
    if not config:
        return JSONResponse(status_code=404, content={"error": "Business not found"})
    if "booking_page" not in config.enabled_channels:
        return JSONResponse(status_code=403, content={"error": "Online booking is not enabled for this business"})

    result = await appointment_service.check_availability(
        config=config,
        date=date,
        staff_name=staff_name,
    )
    return result


@app.post("/api/booking/{tenant_id}/book")
async def booking_submit(tenant_id: str, req: BookingRequest):
    """Submit a booking from the public booking page."""
    config = await tenant_service.load_tenant_config(tenant_id)
    if not config:
        return JSONResponse(status_code=404, content={"error": "Business not found"})
    if "booking_page" not in config.enabled_channels:
        return JSONResponse(status_code=403, content={"error": "Online booking is not enabled for this business"})

    result = await appointment_service.book_appointment(
        config=config,
        customer_name=req.customer_name,
        customer_phone=req.customer_phone,
        service=req.service,
        date=req.date,
        time_slot=req.time_slot,
        staff_name=req.staff_name,
    )

    if not result.get("success"):
        return JSONResponse(status_code=409, content=result)
    return result


# ── Web Chat — WebSocket /ws/chat ────────────────────────────────────
# Browser chat widget connects here for text-based appointment booking.


@app.websocket("/ws/chat")
async def chat_websocket_endpoint(websocket: WebSocket):
    """Handle browser chat WebSocket connection."""
    # Get tenant_id from query params
    tenant_id = websocket.query_params.get("tenant_id")
    if not tenant_id:
        await websocket.accept()
        await websocket.send_json({
            "type": "error",
            "text": "Missing tenant_id parameter.",
        })
        await websocket.close()
        return

    await handle_chat_websocket(websocket, tenant_id)


# ── WebSocket — /ws ─────────────────────────────────────────────────
# Twilio connects here after receiving the TwiML response.
# We extract the tenant_id from custom parameters, load the tenant
# config, and run the bot with dynamic prompts and schemas.


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """Handle Twilio WebSocket connection with tenant routing."""
    await websocket.accept()

    try:
        # Parse the Twilio WebSocket start messages
        # This reads the first 2 messages to detect provider and extract call data
        transport_type, call_data = await parse_telephony_websocket(websocket)

        logger.info(f"WebSocket connected: type={transport_type}, data={call_data}")

        # Extract tenant_id from Twilio custom parameters
        custom_params = call_data.get("body", {})
        tenant_id = custom_params.get("tenant_id")
        from_number = custom_params.get("from_number", "")

        if not tenant_id:
            logger.error("No tenant_id in custom parameters! Cannot route call.")
            await websocket.close()
            return

        # Load tenant configuration
        config = await tenant_service.load_tenant_config(tenant_id)
        if not config:
            logger.error(f"Failed to load config for tenant: {tenant_id}")
            await websocket.close()
            return

        logger.info(
            f"Tenant loaded: {config.business_name} ({config.business_type}) "
            f"— {len(config.staff)} staff, {len(config.services)} services"
        )

        # Create the Twilio transport using pipecat's internal helper
        params = FastAPIWebsocketParams(
            audio_in_enabled=True,
            audio_out_enabled=True,
        )
        transport = await _create_telephony_transport(
            websocket, params, transport_type, call_data
        )

        # Run the tenant-specific bot
        await run_tenant_bot(transport, config, from_number)

    except Exception as e:
        import traceback
        logger.error(f"WebSocket error: {e}\n{traceback.format_exc()}")
        try:
            await websocket.close()
        except Exception:
            pass


# ── Bot pipeline builder ────────────────────────────────────────────


async def run_tenant_bot(transport, config: TenantConfig, from_number: str = ""):
    """Build and run a complete bot pipeline for a specific tenant."""

    logger.info(f"Starting bot for {config.business_name}")

    # ── Services ──
    stt = DeepgramSTTService(api_key=os.getenv("DEEPGRAM_API_KEY"))

    tts = CartesiaTTSService(
        api_key=os.getenv("CARTESIA_API_KEY"),
        voice_id=config.voice_id,
    )

    llm = OpenAILLMService(api_key=os.getenv("OPENAI_API_KEY"))

    # ── Register function handlers (tenant-aware) ──

    async def handle_check_availability(params: FunctionCallParams):
        logger.info(f"[{config.tenant_id}] Checking availability: {params.arguments}")
        result = await appointment_service.check_availability(
            config=config,
            date=params.arguments["date"],
            staff_name=params.arguments["staff_name"],
            time_slot=params.arguments.get("time_slot"),
        )
        logger.info(f"[{config.tenant_id}] Availability result: {result}")
        await params.result_callback(result)

    async def handle_book_appointment(params: FunctionCallParams):
        logger.info(f"[{config.tenant_id}] Booking appointment: {params.arguments}")
        result = await appointment_service.book_appointment(
            config=config,
            customer_name=params.arguments["customer_name"],
            customer_phone=params.arguments["customer_phone"],
            service=params.arguments["service"],
            date=params.arguments["date"],
            time_slot=params.arguments["time_slot"],
            staff_name=params.arguments["staff_name"],
        )
        logger.info(f"[{config.tenant_id}] Booking result: {result}")
        await params.result_callback(result)

    async def handle_cancel_appointment(params: FunctionCallParams):
        logger.info(f"[{config.tenant_id}] Cancelling: {params.arguments}")
        result = await appointment_service.cancel_appointment(
            config=config,
            customer_phone=params.arguments["customer_phone"],
            date=params.arguments.get("date"),
            time_slot=params.arguments.get("time_slot"),
        )
        logger.info(f"[{config.tenant_id}] Cancel result: {result}")
        await params.result_callback(result)

    async def handle_get_services(params: FunctionCallParams):
        logger.info(f"[{config.tenant_id}] Getting services")
        result = await appointment_service.get_services(config)
        await params.result_callback(result)

    async def handle_get_staff(params: FunctionCallParams):
        logger.info(f"[{config.tenant_id}] Getting staff")
        result = await appointment_service.get_staff(config)
        await params.result_callback(result)

    async def handle_end_call(params: FunctionCallParams):
        logger.info(f"[{config.tenant_id}] AI ending call — pushing EndTaskFrame upstream")
        await params.result_callback({"status": "ending"})
        await params.llm.push_frame(
            EndTaskFrame(reason="AI said goodbye"),
            FrameDirection.UPSTREAM,
        )

    llm.register_function("check_availability", handle_check_availability)
    llm.register_function("book_appointment", handle_book_appointment)
    llm.register_function("cancel_appointment", handle_cancel_appointment)
    llm.register_function("get_services", handle_get_services)
    llm.register_function("get_staff", handle_get_staff)
    llm.register_function("end_call", handle_end_call)

    # ── Build dynamic system prompt and tools ──

    system_prompt = bot_factory.build_system_prompt(config)
    tools = bot_factory.build_tools(config)

    messages = [{"role": "system", "content": system_prompt}]
    context = LLMContext(messages, tools)

    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(
        context,
        user_params=LLMUserAggregatorParams(
            user_turn_strategies=UserTurnStrategies(
                stop=[
                    TurnAnalyzerUserTurnStopStrategy(
                        turn_analyzer=LocalSmartTurnAnalyzerV3()
                    )
                ]
            ),
            vad_analyzer=SileroVADAnalyzer(params=VADParams(stop_secs=0.2)),
        ),
    )

    # ── Build pipeline ──

    pipeline = Pipeline(
        [
            transport.input(),
            stt,
            user_aggregator,
            llm,
            tts,
            transport.output(),
            assistant_aggregator,
        ]
    )

    task = PipelineTask(
        pipeline,
        params=PipelineParams(
            enable_metrics=True,
            enable_usage_metrics=True,
        ),
    )

    # ── Transport event handlers ──

    @transport.event_handler("on_client_connected")
    async def on_client_connected(transport, client):
        logger.info(f"[{config.tenant_id}] Client connected to {config.business_name}")
        greeting = bot_factory.build_greeting_message(config)
        messages.append({"role": "system", "content": greeting})
        await task.queue_frames([LLMRunFrame()])

    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(transport, client):
        logger.info(f"[{config.tenant_id}] Client disconnected from {config.business_name}")
        await task.cancel()

    # ── Run ──

    runner = PipelineRunner(handle_sigint=False)
    await runner.run(task)


# ── Entry point ─────────────────────────────────────────────────────

if __name__ == "__main__":
    args = parse_args()

    if args.twilio:
        if not args.proxy:
            print("ERROR: --proxy required for Twilio mode")
            print("Usage: uv run app.py --twilio --proxy YOUR-DOMAIN")
            sys.exit(1)

        # Set PROXY_DOMAIN so the webhook handler can use it
        os.environ["PROXY_DOMAIN"] = args.proxy

        print(f"  Mode: Twilio (phone + SMS + email)")
        print(f"  Proxy: {args.proxy}")
        print(f"  Voice WebSocket: wss://{args.proxy}/ws")
        print(f"  SMS Webhook: https://{args.proxy}/webhooks/sms")
        print(f"  Email Webhook: https://{args.proxy}/webhooks/email")
    else:
        print(f"  Mode: Local (browser WebRTC not yet supported)")
        print(f"  Note: Use --twilio --proxy DOMAIN for phone mode")

    print(f"  Server: http://{args.host}:{args.port}")
    print(f"  Chat Widget: http://{args.host}:{args.port}/static/chat.html?tenant_id=t_001")
    print(f"  Chat WebSocket: ws://{args.host}:{args.port}/ws/chat?tenant_id=t_001")
    print(f"  Booking Page: http://{args.host}:{args.port}/book/t_001")
    print()

    uvicorn.run(app, host=args.host, port=args.port)
