"""Multi-tenant appointment service.

All DynamoDB operations for checking availability, booking, and cancelling
appointments. Every function requires a TenantConfig so data is fully isolated
between tenants via key prefixing.

DynamoDB key patterns:
  Appointment: PK=APPT#{tenant_id}#{staff}#{date}  SK={time_slot}
  Customer GSI: GSI1PK=CUST#{tenant_id}#{phone}    GSI1SK={date}#{time_slot}
"""

import asyncio
from datetime import datetime
from typing import Optional

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from loguru import logger

import calendar_service
from tenant_service import TenantConfig

TABLE_NAME = "VoiceAI_Platform"
REGION = "us-west-2"

# ── DynamoDB Table (lazy init) ──────────────────────────────────────

_dynamodb_table = None


def _get_table():
    global _dynamodb_table
    if _dynamodb_table is None:
        dynamodb = boto3.resource("dynamodb", region_name=REGION)
        _dynamodb_table = dynamodb.Table(TABLE_NAME)
    return _dynamodb_table


# ── Sync helpers (run inside asyncio.to_thread) ─────────────────────


def _get_services_sync(config: TenantConfig) -> dict:
    return {
        "services": [
            {"name": svc.name, "price": svc.price, "duration_minutes": svc.duration_minutes}
            for svc in config.services
        ]
    }


def _get_staff_sync(config: TenantConfig) -> dict:
    return {
        "staff": [
            {"name": s.name, "title": s.title}
            for s in config.staff
        ]
    }


def _check_availability_sync(
    config: TenantConfig,
    date: str,
    staff_name: str,
    time_slot: Optional[str] = None,
) -> dict:
    all_slots = config.all_slots

    # Validate staff
    if staff_name not in config.staff_names:
        return {
            "available": False,
            "error": f"Unknown staff member. Available: {', '.join(config.staff_names)}.",
        }

    # Validate date
    try:
        date_obj = datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        return {"available": False, "error": "Invalid date format. Use YYYY-MM-DD."}

    day_name = date_obj.strftime("%A")
    if day_name not in config.open_days:
        return {
            "available": False,
            "error": f"We are closed on {day_name}s. Please pick another day.",
        }

    if date_obj.date() < datetime.now().date():
        return {"available": False, "error": "Cannot book appointments in the past."}

    table = _get_table()
    pk = f"APPT#{config.tenant_id}#{staff_name}#{date}"

    if time_slot:
        # Check a specific slot
        if time_slot not in all_slots:
            return {
                "available": False,
                "error": (
                    f"Invalid time slot. Slots are every {config.slot_duration_minutes} minutes "
                    f"from {all_slots[0]} to {all_slots[-1]}."
                ),
            }

        response = table.get_item(Key={"PK": pk, "SK": time_slot})
        item = response.get("Item")

        if item and item.get("status") == "booked":
            return {
                "available": False,
                "message": f"{staff_name} is already booked at {time_slot} on {date}.",
            }
        return {
            "available": True,
            "message": f"{staff_name} is available at {time_slot} on {date}.",
        }

    # Return all available slots for the day
    response = table.query(KeyConditionExpression=Key("PK").eq(pk))
    booked = {
        item["SK"]
        for item in response["Items"]
        if item.get("status") == "booked"
    }
    available = [s for s in all_slots if s not in booked]

    # Filter past slots if date is today
    if date_obj.date() == datetime.now().date():
        now_str = datetime.now().strftime("%H:%M")
        available = [s for s in available if s > now_str]

    if not available:
        return {
            "available": False,
            "message": f"{staff_name} has no available slots on {date}.",
            "available_slots": [],
        }

    return {
        "available": True,
        "available_slots": available,
        "message": f"{staff_name} has {len(available)} available slots on {date}.",
    }


def _book_appointment_sync(
    config: TenantConfig,
    customer_name: str,
    customer_phone: str,
    service: str,
    date: str,
    time_slot: str,
    staff_name: str,
) -> dict:
    all_slots = config.all_slots
    service_map = config.service_map

    # Validation
    if service not in service_map:
        return {
            "success": False,
            "error": f"Unknown service. Available: {', '.join(service_map.keys())}.",
        }
    if staff_name not in config.staff_names:
        return {
            "success": False,
            "error": f"Unknown staff member. Available: {', '.join(config.staff_names)}.",
        }
    if time_slot not in all_slots:
        return {"success": False, "error": "Invalid time slot."}

    try:
        date_obj = datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        return {"success": False, "error": "Invalid date format. Use YYYY-MM-DD."}

    day_name = date_obj.strftime("%A")
    if day_name not in config.open_days:
        return {"success": False, "error": f"We are closed on {day_name}s."}
    if date_obj.date() < datetime.now().date():
        return {"success": False, "error": "Cannot book in the past."}

    svc = service_map[service]
    num_slots = (svc.duration_minutes + config.slot_duration_minutes - 1) // config.slot_duration_minutes

    # Calculate consecutive slots needed
    start_idx = all_slots.index(time_slot)
    needed_slots = all_slots[start_idx: start_idx + num_slots]

    if len(needed_slots) < num_slots:
        return {
            "success": False,
            "error": "Not enough time before closing for this service at that time.",
        }

    # Verify last slot doesn't exceed closing
    last_slot = needed_slots[-1]
    last_h, last_m = map(int, last_slot.split(":"))
    end_minutes = last_h * 60 + last_m + config.slot_duration_minutes
    if end_minutes > config.hours["close"] * 60:
        return {
            "success": False,
            "error": f"Appointment would extend past closing time.",
        }

    pk = f"APPT#{config.tenant_id}#{staff_name}#{date}"
    now_iso = datetime.now().isoformat()

    # Atomic multi-slot booking with TransactWriteItems
    client = boto3.client("dynamodb", region_name=REGION)

    transact_items = []
    for slot in needed_slots:
        transact_items.append(
            {
                "Put": {
                    "TableName": TABLE_NAME,
                    "Item": {
                        "PK": {"S": pk},
                        "SK": {"S": slot},
                        "tenant_id": {"S": config.tenant_id},
                        "customer_name": {"S": customer_name},
                        "customer_phone": {"S": customer_phone},
                        "service": {"S": service},
                        "staff_name": {"S": staff_name},
                        "service_duration": {"N": str(svc.duration_minutes)},
                        "service_price": {"N": str(int(svc.price))},
                        "appointment_date": {"S": date},
                        "created_at": {"S": now_iso},
                        "status": {"S": "booked"},
                        # GSI1 attributes for customer lookup
                        "GSI1PK": {"S": f"CUST#{config.tenant_id}#{customer_phone}"},
                        "GSI1SK": {"S": f"{date}#{slot}"},
                    },
                    "ConditionExpression": "attribute_not_exists(PK) OR #s = :cancelled",
                    "ExpressionAttributeNames": {"#s": "status"},
                    "ExpressionAttributeValues": {":cancelled": {"S": "cancelled"}},
                }
            }
        )

    try:
        client.transact_write_items(TransactItems=transact_items)
    except ClientError as e:
        if e.response["Error"]["Code"] == "TransactionCanceledException":
            return {
                "success": False,
                "error": "One or more time slots are already booked. Please choose a different time.",
            }
        logger.error(f"DynamoDB error: {e}")
        raise

    end_h = end_minutes // 60
    end_m = end_minutes % 60

    appointment_data = {
        "customer_name": customer_name,
        "phone": customer_phone,
        "service": service,
        "staff": staff_name,
        "date": date,
        "time": time_slot,
        "end_time": f"{end_h:02d}:{end_m:02d}",
        "price": svc.price,
        "duration_minutes": svc.duration_minutes,
    }

    # Google Calendar sync (best-effort — never blocks booking)
    if config.google_calendar_id:
        try:
            event_id = calendar_service._sync_booking_to_calendar_sync(
                calendar_id=config.google_calendar_id,
                business_name=config.business_name,
                timezone=config.timezone,
                appointment=appointment_data,
            )
            if event_id:
                appointment_data["calendar_event_id"] = event_id
                # Store calendar_event_id in the first slot for later cancellation
                table = _get_table()
                table.update_item(
                    Key={"PK": pk, "SK": time_slot},
                    UpdateExpression="SET calendar_event_id = :eid",
                    ExpressionAttributeValues={":eid": event_id},
                )
        except Exception as e:
            logger.error(f"Calendar sync failed (booking still confirmed): {e}")

    return {
        "success": True,
        "appointment": appointment_data,
        "message": (
            f"Appointment booked! {service} with {staff_name} on {date} at {time_slot}. "
            f"Price: ${svc.price:.0f}."
        ),
    }


def _cancel_appointment_sync(
    config: TenantConfig,
    customer_phone: str,
    date: Optional[str] = None,
    time_slot: Optional[str] = None,
) -> dict:
    table = _get_table()

    # Look up by phone via GSI1
    gsi_pk = f"CUST#{config.tenant_id}#{customer_phone}"
    key_cond = Key("GSI1PK").eq(gsi_pk)
    if date:
        key_cond = key_cond & Key("GSI1SK").begins_with(date)

    response = table.query(
        IndexName="GSI1",
        KeyConditionExpression=key_cond,
    )

    appointments = [
        item for item in response["Items"] if item.get("status") == "booked"
    ]

    if not appointments:
        return {
            "success": False,
            "error": "No booked appointments found for that phone number.",
        }

    # Filter to specific time if given
    if time_slot and date:
        appointments = [a for a in appointments if a["SK"] == time_slot]
        if not appointments:
            return {
                "success": False,
                "error": "No appointment found at that specific date and time.",
            }

    # If multiple distinct bookings remain, ask caller to be specific
    if len(appointments) > 1 and not (date and time_slot):
        seen = set()
        unique = []
        for a in appointments:
            key = (a["PK"], a["service"])
            if key not in seen:
                seen.add(key)
                # Parse staff and date from PK: APPT#t_001#Jake#2026-02-14
                parts = a["PK"].split("#")
                staff = parts[2] if len(parts) >= 3 else "Unknown"
                dt = parts[3] if len(parts) >= 4 else "Unknown"
                unique.append(
                    {
                        "service": a["service"],
                        "staff": staff,
                        "date": dt,
                        "time": a["SK"],
                    }
                )
        if len(unique) > 1:
            return {
                "success": False,
                "multiple_found": True,
                "appointments": unique,
                "message": (
                    "Multiple appointments found. Please specify which one to "
                    "cancel by providing the date and time."
                ),
            }

    # Cancel all slots belonging to this booking
    target = appointments[0]
    target_pk = target["PK"]
    target_service = target["service"]

    # Find all slots for same PK + customer + service
    all_for_day = table.query(
        KeyConditionExpression=Key("PK").eq(target_pk)
    )
    slots_to_cancel = [
        item
        for item in all_for_day["Items"]
        if item.get("customer_phone") == customer_phone
        and item.get("status") == "booked"
        and item.get("service") == target_service
    ]

    # Grab calendar_event_id before cancelling (stored on first slot)
    calendar_event_id = None
    for slot_item in slots_to_cancel:
        if slot_item.get("calendar_event_id"):
            calendar_event_id = slot_item["calendar_event_id"]
            break

    for slot_item in slots_to_cancel:
        table.update_item(
            Key={"PK": slot_item["PK"], "SK": slot_item["SK"]},
            UpdateExpression="SET #s = :cancelled",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":cancelled": "cancelled"},
        )

    # Delete Google Calendar event (best-effort)
    if calendar_event_id and config.google_calendar_id:
        try:
            calendar_service._delete_calendar_event_sync(
                config.google_calendar_id, calendar_event_id
            )
        except Exception as e:
            logger.error(f"Calendar event deletion failed: {e}")

    # Parse staff and date from PK
    parts = target_pk.split("#")
    staff = parts[2] if len(parts) >= 3 else "Unknown"
    date_str = parts[3] if len(parts) >= 4 else "Unknown"

    return {
        "success": True,
        "message": (
            f"Appointment cancelled: {target_service} with {staff} "
            f"on {date_str} at {target['SK']}."
        ),
    }


# ── Public async API (called from bot handlers) ────────────────────


async def get_services(config: TenantConfig) -> dict:
    return _get_services_sync(config)


async def get_staff(config: TenantConfig) -> dict:
    return _get_staff_sync(config)


async def check_availability(
    config: TenantConfig,
    date: str,
    staff_name: str,
    time_slot: Optional[str] = None,
) -> dict:
    return await asyncio.to_thread(
        _check_availability_sync, config, date, staff_name, time_slot
    )


async def book_appointment(
    config: TenantConfig,
    customer_name: str,
    customer_phone: str,
    service: str,
    date: str,
    time_slot: str,
    staff_name: str,
) -> dict:
    return await asyncio.to_thread(
        _book_appointment_sync,
        config,
        customer_name,
        customer_phone,
        service,
        date,
        time_slot,
        staff_name,
    )


async def cancel_appointment(
    config: TenantConfig,
    customer_phone: str,
    date: Optional[str] = None,
    time_slot: Optional[str] = None,
) -> dict:
    return await asyncio.to_thread(
        _cancel_appointment_sync, config, customer_phone, date, time_slot
    )
