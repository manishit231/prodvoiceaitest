"""Unified text conversation engine for all text-based channels.

Wraps OpenAI with function calling and DynamoDB session management.
Used by SMS, WhatsApp, Web Chat, Facebook Messenger, Instagram, and Email channels.

Every text channel calls:
    chat_service.process_message(tenant_id, session_id, user_message, channel)

The service handles:
- Multi-turn conversation state (stored in DynamoDB with 24h TTL)
- OpenAI function calling (check_availability, book_appointment, etc.)
- Executing booking functions via appointment_service
- Returning the assistant's text response
"""

import asyncio
import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

import boto3
from boto3.dynamodb.conditions import Key
from loguru import logger

import appointment_service
import bot_factory
import tenant_service
from tenant_service import TenantConfig

TABLE_NAME = "VoiceAI_Platform"
REGION = "us-west-2"

# Session TTL: 24 hours
SESSION_TTL_SECONDS = 86400

# Max conversation history to keep (to avoid token overflow)
MAX_HISTORY_MESSAGES = 40


@dataclass
class ConversationSession:
    """Tracks a multi-turn conversation for a specific channel + user."""

    tenant_id: str
    channel: str
    session_id: str  # phone number, email, browser session ID, etc.
    messages: list = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""


# ── DynamoDB table (lazy init) ──────────────────────────────────────

_dynamodb_table = None


def _get_table():
    global _dynamodb_table
    if _dynamodb_table is None:
        dynamodb = boto3.resource("dynamodb", region_name=REGION)
        _dynamodb_table = dynamodb.Table(TABLE_NAME)
    return _dynamodb_table


# ── OpenAI client (lazy init) ───────────────────────────────────────

_openai_client = None


def _get_openai_client():
    global _openai_client
    if _openai_client is None:
        from openai import AsyncOpenAI

        _openai_client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    return _openai_client


# ── Session CRUD (sync, wrapped in asyncio.to_thread) ───────────────


def _load_session_sync(tenant_id: str, session_id: str, channel: str) -> ConversationSession:
    """Load or create a conversation session from DynamoDB."""
    table = _get_table()
    pk = f"SESSION#{tenant_id}#{channel}#{session_id}"
    sk = "CONV"

    response = table.get_item(Key={"PK": pk, "SK": sk})
    item = response.get("Item")

    if item:
        messages = json.loads(item.get("messages", "[]"))
        return ConversationSession(
            tenant_id=tenant_id,
            channel=channel,
            session_id=session_id,
            messages=messages,
            created_at=item.get("created_at", ""),
            updated_at=item.get("updated_at", ""),
        )

    # New session
    now = datetime.utcnow().isoformat()
    return ConversationSession(
        tenant_id=tenant_id,
        channel=channel,
        session_id=session_id,
        messages=[],
        created_at=now,
        updated_at=now,
    )


def _save_session_sync(session: ConversationSession):
    """Save conversation session to DynamoDB with TTL."""
    table = _get_table()
    pk = f"SESSION#{session.tenant_id}#{session.channel}#{session.session_id}"
    sk = "CONV"
    now = datetime.utcnow().isoformat()
    ttl_epoch = int(time.time()) + SESSION_TTL_SECONDS

    # Trim history if too long (keep system context fresh)
    messages_to_save = session.messages
    if len(messages_to_save) > MAX_HISTORY_MESSAGES:
        messages_to_save = messages_to_save[-MAX_HISTORY_MESSAGES:]

    table.put_item(
        Item={
            "PK": pk,
            "SK": sk,
            "tenant_id": session.tenant_id,
            "channel": session.channel,
            "session_id": session.session_id,
            "messages": json.dumps(messages_to_save),
            "created_at": session.created_at,
            "updated_at": now,
            "ttl": ttl_epoch,
        }
    )


# ── Function execution ──────────────────────────────────────────────


async def _execute_tool_call(config: TenantConfig, tool_call) -> dict:
    """Execute a booking function and return the result."""
    fn_name = tool_call.function.name
    args = json.loads(tool_call.function.arguments)

    logger.info(f"[{config.tenant_id}] Chat tool call: {fn_name}({args})")

    if fn_name == "check_availability":
        result = await appointment_service.check_availability(
            config=config,
            date=args["date"],
            staff_name=args["staff_name"],
            time_slot=args.get("time_slot"),
        )
    elif fn_name == "book_appointment":
        result = await appointment_service.book_appointment(
            config=config,
            customer_name=args["customer_name"],
            customer_phone=args["customer_phone"],
            service=args["service"],
            date=args["date"],
            time_slot=args["time_slot"],
            staff_name=args["staff_name"],
        )
    elif fn_name == "cancel_appointment":
        result = await appointment_service.cancel_appointment(
            config=config,
            customer_phone=args["customer_phone"],
            date=args.get("date"),
            time_slot=args.get("time_slot"),
        )
    elif fn_name == "get_services":
        result = await appointment_service.get_services(config)
    elif fn_name == "get_staff":
        result = await appointment_service.get_staff(config)
    else:
        result = {"error": f"Unknown function: {fn_name}"}

    logger.info(f"[{config.tenant_id}] Tool result: {result}")
    return result


# ── Convert bot_factory tools to OpenAI chat format ─────────────────


def _tools_schema_to_openai_format(config: TenantConfig) -> list[dict]:
    """Convert pipecat ToolsSchema to OpenAI chat API tools format."""
    pipecat_tools = bot_factory.build_tools(config)
    openai_tools = []

    for fn_schema in pipecat_tools.standard_tools:
        # Build the properties dict
        properties = {}
        for prop_name, prop_def in fn_schema.properties.items():
            properties[prop_name] = {k: v for k, v in prop_def.items()}

        tool = {
            "type": "function",
            "function": {
                "name": fn_schema.name,
                "description": fn_schema.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": fn_schema.required,
                },
            },
        }
        openai_tools.append(tool)

    return openai_tools


# ── Main public API ─────────────────────────────────────────────────


async def process_message(
    tenant_id: str,
    session_id: str,
    user_message: str,
    channel: str,
    metadata: Optional[dict] = None,
) -> str:
    """
    Process a user message and return the assistant's text response.

    This is the single entry point for ALL text-based channels.

    Args:
        tenant_id: The tenant (business) ID
        session_id: Unique per-conversation (phone number, email, session UUID)
        user_message: The customer's text message
        channel: Channel name ("sms", "whatsapp", "web_chat", "messenger", "instagram", "email")
        metadata: Optional channel-specific data

    Returns:
        The assistant's text response string
    """
    # 1. Load tenant config
    config = await tenant_service.load_tenant_config(tenant_id)
    if not config:
        logger.error(f"[{tenant_id}] Failed to load tenant config")
        return "Sorry, this service is not available right now. Please try again later."

    # 2. Load or create conversation session
    session = await asyncio.to_thread(
        _load_session_sync, tenant_id, session_id, channel
    )

    # 3. Add user message to history
    session.messages.append({"role": "user", "content": user_message})

    # 4. Build system prompt (text mode) and tools
    system_prompt = bot_factory.build_text_system_prompt(config)
    tools = _tools_schema_to_openai_format(config)

    # 5. Prepare messages for OpenAI
    api_messages = [
        {"role": "system", "content": system_prompt},
        *session.messages,
    ]

    # 6. Call OpenAI with function calling
    client = _get_openai_client()

    try:
        response = await client.chat.completions.create(
            model="gpt-4o",
            messages=api_messages,
            tools=tools,
            tool_choice="auto",
            temperature=0.7,
        )

        message = response.choices[0].message

        # 7. Handle tool calls (may need multiple rounds)
        max_rounds = 5  # Safety limit
        round_count = 0

        while message.tool_calls and round_count < max_rounds:
            round_count += 1

            # Add assistant message with tool calls to history
            session.messages.append({
                "role": "assistant",
                "content": message.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments,
                        },
                    }
                    for tc in message.tool_calls
                ],
            })

            # Execute each tool call
            for tool_call in message.tool_calls:
                result = await _execute_tool_call(config, tool_call)
                session.messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": json.dumps(result),
                })

            # Call OpenAI again with tool results
            api_messages = [
                {"role": "system", "content": system_prompt},
                *session.messages,
            ]

            response = await client.chat.completions.create(
                model="gpt-4o",
                messages=api_messages,
                tools=tools,
                tool_choice="auto",
                temperature=0.7,
            )
            message = response.choices[0].message

        # 8. Get final text response
        assistant_text = message.content or "I'm sorry, I couldn't process that. Could you try again?"

        # Add final assistant message to history
        session.messages.append({"role": "assistant", "content": assistant_text})

        # 9. Save session to DynamoDB
        await asyncio.to_thread(_save_session_sync, session)

        logger.info(
            f"[{config.tenant_id}] Chat [{channel}] {session_id}: "
            f"'{user_message[:50]}...' -> '{assistant_text[:50]}...'"
        )

        return assistant_text

    except Exception as e:
        logger.error(f"[{tenant_id}] OpenAI error: {e}")
        return "I'm sorry, I'm having trouble right now. Please try again in a moment."
