"""AWS SES/SNS email channel adapter.

Handles inbound emails received via AWS SES -> SNS -> HTTPS webhook.
Routes them through chat_service for appointment booking and sends
replies via SES with proper email threading.

Email Flow:
    Customer emails book@elitecuts.prodvoice.link
    -> SES receives (MX record points to SES)
    -> SES Receipt Rule forwards to SNS topic
    -> SNS POSTs to https://prodvoice.link/webhooks/email
    -> This adapter parses the email, strips quotes/signatures
    -> Resolves tenant from subdomain "elitecuts" (EMAIL# DynamoDB lookup)
    -> chat_service.process_message(tenant_id, sender_email, body, "email")
    -> Sends AI reply via SES with threading headers (In-Reply-To, References)

SNS Notification Types:
    SubscriptionConfirmation — one-time handshake when SNS topic subscribes
    Notification — actual email content from SES
"""

import asyncio
import email
import json
import os
import re
from email import policy
from email.mime.text import MIMEText
from html import unescape
from typing import Optional

import boto3
from loguru import logger

import chat_service
import tenant_service

# Email domain — all tenant emails are subdomains of this
EMAIL_DOMAIN = os.getenv("EMAIL_DOMAIN", "prodvoice.link")

# AWS region for SES
SES_REGION = os.getenv("AWS_REGION", "us-west-2")

# From address for replies (uses subdomain matching the tenant)
# Format: "Business Name <no-reply@{subdomain}.prodvoice.link>"

# ── SNS Message Handling ──────────────────────────────────────────────


async def handle_email_webhook(request) -> dict:
    """Handle incoming SNS notification (email via SES).

    SNS sends two types of messages:
    1. SubscriptionConfirmation — we must confirm the subscription
    2. Notification — contains the actual email from SES

    Returns:
        dict with status for FastAPI JSON response
    """
    # SNS sends JSON with content-type text/plain
    body = await request.body()
    try:
        sns_message = json.loads(body)
    except json.JSONDecodeError:
        logger.error(f"Failed to parse SNS message body")
        return {"status": "error", "message": "Invalid JSON"}

    message_type = sns_message.get("Type", "")

    # ── Handle subscription confirmation (one-time setup) ──
    if message_type == "SubscriptionConfirmation":
        return await _handle_subscription_confirmation(sns_message)

    # ── Handle actual email notification ──
    if message_type == "Notification":
        return await _handle_email_notification(sns_message)

    # ── Handle unsubscribe confirmation ──
    if message_type == "UnsubscribeConfirmation":
        logger.info("SNS UnsubscribeConfirmation received")
        return {"status": "ok", "message": "Unsubscribe noted"}

    logger.warning(f"Unknown SNS message type: {message_type}")
    return {"status": "ignored", "message": f"Unknown type: {message_type}"}


async def _handle_subscription_confirmation(sns_message: dict) -> dict:
    """Confirm SNS topic subscription by visiting the SubscribeURL."""
    subscribe_url = sns_message.get("SubscribeURL", "")
    topic_arn = sns_message.get("TopicArn", "")

    logger.info(f"SNS SubscriptionConfirmation for topic: {topic_arn}")

    if not subscribe_url:
        logger.error("No SubscribeURL in confirmation message")
        return {"status": "error", "message": "No SubscribeURL"}

    # Confirm by making HTTP GET to the SubscribeURL
    try:
        import urllib.request

        await asyncio.to_thread(urllib.request.urlopen, subscribe_url)
        logger.info(f"SNS subscription confirmed for: {topic_arn}")
        return {"status": "ok", "message": "Subscription confirmed"}
    except Exception as e:
        logger.error(f"Failed to confirm SNS subscription: {e}")
        return {"status": "error", "message": str(e)}


async def _handle_email_notification(sns_message: dict) -> dict:
    """Process an actual email notification from SES via SNS."""
    try:
        # SNS wraps the SES notification in a "Message" field (as a JSON string)
        message_str = sns_message.get("Message", "")
        ses_notification = json.loads(message_str)

        # Extract email data from SES notification
        email_data = _parse_ses_notification(ses_notification)

        if not email_data:
            logger.warning("Could not parse email from SES notification")
            return {"status": "error", "message": "Failed to parse email"}

        sender = email_data["sender"]
        recipient = email_data["recipient"]
        subject = email_data["subject"]
        body_text = email_data["body"]
        message_id = email_data["message_id"]
        references = email_data.get("references", "")

        logger.info(
            f"Email received: from={sender}, to={recipient}, "
            f"subject='{subject[:50]}', body_len={len(body_text)}"
        )

        # ── Resolve tenant from recipient email ──
        subdomain = _extract_subdomain(recipient)
        if not subdomain:
            logger.error(f"Cannot extract subdomain from: {recipient}")
            return {"status": "error", "message": "Invalid recipient address"}

        tenant_id = await tenant_service.lookup_tenant_by_email(subdomain)
        if not tenant_id:
            logger.error(f"No tenant found for email subdomain: {subdomain}")
            return {"status": "error", "message": f"No tenant for {subdomain}"}

        # ── Check if email channel is enabled ──
        config = await tenant_service.load_tenant_config(tenant_id)
        if not config:
            logger.error(f"Failed to load config for tenant: {tenant_id}")
            return {"status": "error", "message": "Tenant config not found"}

        if "email" not in config.enabled_channels:
            logger.warning(f"Email not enabled for tenant {tenant_id}")
            # Don't reply — just ignore
            return {"status": "ignored", "message": "Email channel not enabled"}

        # ── Strip quoted replies and signatures ──
        clean_body = _strip_thread_and_signature(body_text)

        if not clean_body.strip():
            logger.warning(f"Empty email body after stripping (from {sender})")
            clean_body = "(empty message)"

        logger.info(
            f"[{tenant_id}] Processing email from {sender}: '{clean_body[:80]}...'"
        )

        # ── Process through chat engine ──
        response_text = await chat_service.process_message(
            tenant_id=tenant_id,
            session_id=sender,  # Session keyed by sender email
            user_message=clean_body,
            channel="email",
            metadata={
                "sender": sender,
                "recipient": recipient,
                "subject": subject,
                "message_id": message_id,
                "references": references,
            },
        )

        # ── Send reply via SES ──
        await _send_email_reply(
            config=config,
            to_address=sender,
            from_subdomain=subdomain,
            subject=subject,
            reply_body=response_text,
            in_reply_to=message_id,
            references=references,
        )

        logger.info(f"[{tenant_id}] Email reply sent to {sender}")
        return {"status": "ok", "message": "Email processed and reply sent"}

    except Exception as e:
        logger.error(f"Error processing email notification: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return {"status": "error", "message": str(e)}


# ── SES Notification Parsing ──────────────────────────────────────────


def _parse_ses_notification(ses_notification: dict) -> Optional[dict]:
    """Parse an SES notification to extract email data.

    SES notification structure (SNS action):
    {
        "notificationType": "Received",
        "mail": {
            "source": "sender@example.com",
            "destination": ["book@elitecuts.prodvoice.link"],
            "commonHeaders": {
                "subject": "I need a haircut",
                "from": ["John <sender@example.com>"],
                "messageId": "<abc@mail.gmail.com>"
            }
        },
        "content": "raw MIME email..."  (if SNS action with content included)
    }
    """
    try:
        notification_type = ses_notification.get("notificationType", "")
        if notification_type != "Received":
            logger.warning(f"Unexpected SES notification type: {notification_type}")
            return None

        mail_obj = ses_notification.get("mail", {})
        common_headers = mail_obj.get("commonHeaders", {})

        sender = mail_obj.get("source", "")
        recipients = mail_obj.get("destination", [])
        recipient = recipients[0] if recipients else ""
        subject = common_headers.get("subject", "(no subject)")
        message_id = common_headers.get("messageId", "")

        # Parse raw email content (MIME) to get the body
        raw_content = ses_notification.get("content", "")

        body = ""
        references = ""

        if raw_content:
            # Parse MIME email
            parsed = email.message_from_string(raw_content, policy=policy.default)
            body = _extract_email_body(parsed)
            references = parsed.get("References", "")

            # If message_id is empty, try from parsed headers
            if not message_id:
                message_id = parsed.get("Message-ID", "")
        else:
            # No raw content — try to get body from notification structure
            # (This happens if SES uses S3 action instead of SNS content)
            body = f"(Email subject: {subject})"
            logger.warning("No raw email content in SNS notification — SES may need SNS action with content")

        return {
            "sender": sender,
            "recipient": recipient,
            "subject": subject,
            "body": body,
            "message_id": message_id,
            "references": references,
        }

    except Exception as e:
        logger.error(f"Error parsing SES notification: {e}")
        return None


# ── Email Body Extraction ─────────────────────────────────────────────


def _extract_email_body(parsed_email) -> str:
    """Extract plain text body from a parsed MIME email.

    Prefers text/plain. Falls back to text/html with HTML tag stripping.
    """
    body = ""

    if parsed_email.is_multipart():
        # Walk through MIME parts, prefer text/plain
        plain_parts = []
        html_parts = []

        for part in parsed_email.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition", ""))

            # Skip attachments
            if "attachment" in content_disposition:
                continue

            if content_type == "text/plain":
                text = part.get_content()
                if isinstance(text, bytes):
                    text = text.decode("utf-8", errors="replace")
                plain_parts.append(text)
            elif content_type == "text/html":
                html = part.get_content()
                if isinstance(html, bytes):
                    html = html.decode("utf-8", errors="replace")
                html_parts.append(html)

        if plain_parts:
            body = "\n".join(plain_parts)
        elif html_parts:
            body = _strip_html("\n".join(html_parts))
    else:
        content_type = parsed_email.get_content_type()
        content = parsed_email.get_content()
        if isinstance(content, bytes):
            content = content.decode("utf-8", errors="replace")

        if content_type == "text/html":
            body = _strip_html(content)
        else:
            body = content

    return body.strip()


def _strip_html(html: str) -> str:
    """Strip HTML tags and convert to plain text.

    Simple approach: remove tags, decode entities, collapse whitespace.
    """
    # Remove style and script blocks
    html = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
    html = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)

    # Replace <br> and <p> with newlines
    html = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
    html = re.sub(r"</p>", "\n", html, flags=re.IGNORECASE)
    html = re.sub(r"<p[^>]*>", "", html, flags=re.IGNORECASE)

    # Remove all other tags
    html = re.sub(r"<[^>]+>", "", html)

    # Decode HTML entities
    text = unescape(html)

    # Collapse whitespace (preserve newlines)
    lines = text.split("\n")
    lines = [" ".join(line.split()) for line in lines]
    text = "\n".join(lines)

    # Remove excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()


# ── Thread and Signature Stripping ────────────────────────────────────


def _strip_thread_and_signature(text: str) -> str:
    """Strip quoted replies and signatures from email text.

    Uses email_reply_parser to isolate just the latest reply.
    Falls back to manual stripping if the library isn't available.
    """
    try:
        from email_reply_parser import EmailReplyParser

        reply = EmailReplyParser.parse_reply(text)
        if reply and reply.strip():
            return reply.strip()
    except ImportError:
        logger.warning("email_reply_parser not installed, using fallback stripping")
    except Exception as e:
        logger.warning(f"email_reply_parser failed: {e}, using fallback")

    # Fallback: manual quote/signature stripping
    return _manual_strip_quotes(text)


def _manual_strip_quotes(text: str) -> str:
    """Fallback quote stripping for when email_reply_parser isn't available."""
    lines = text.split("\n")
    result_lines = []

    for line in lines:
        stripped = line.strip()

        # Stop at common reply indicators
        if stripped.startswith("On ") and stripped.endswith("wrote:"):
            break
        if stripped.startswith(">"):
            continue
        if stripped == "-- ":  # Standard email signature delimiter
            break
        if stripped.startswith("---------- Forwarded message"):
            break
        if stripped.startswith("From:") and "sent:" in stripped.lower():
            break

        result_lines.append(line)

    return "\n".join(result_lines).strip()


# ── Subdomain Extraction ──────────────────────────────────────────────


def _extract_subdomain(recipient_email: str) -> Optional[str]:
    """Extract the tenant subdomain from a recipient email address.

    book@elitecuts.prodvoice.link -> "elitecuts"
    anything@smiledentalcare.prodvoice.link -> "smiledentalcare"
    user@gmail.com -> None (not our domain)
    """
    recipient_email = recipient_email.lower().strip()

    # Match: anything@{subdomain}.{EMAIL_DOMAIN}
    domain = EMAIL_DOMAIN.lower()
    pattern = rf"^[^@]+@([^.]+)\.{re.escape(domain)}$"
    match = re.match(pattern, recipient_email)

    if match:
        return match.group(1)

    logger.warning(f"Cannot extract subdomain from {recipient_email} (domain: {domain})")
    return None


# ── SES Email Reply ───────────────────────────────────────────────────


_ses_client = None


def _get_ses_client():
    """Lazy-init SES client."""
    global _ses_client
    if _ses_client is None:
        _ses_client = boto3.client("ses", region_name=SES_REGION)
    return _ses_client


async def _send_email_reply(
    config,
    to_address: str,
    from_subdomain: str,
    subject: str,
    reply_body: str,
    in_reply_to: str = "",
    references: str = "",
):
    """Send a reply email via AWS SES with proper threading headers.

    Threading headers ensure the reply appears in the same thread
    in Gmail, Outlook, Apple Mail, etc.
    """
    # Build the from address
    from_address = f'"{config.business_name}" <book@{from_subdomain}.{EMAIL_DOMAIN}>'

    # Ensure subject starts with "Re:"
    if not subject.lower().startswith("re:"):
        subject = f"Re: {subject}"

    # Build MIME message with threading headers
    msg = MIMEText(reply_body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = from_address
    msg["To"] = to_address

    # Threading headers
    if in_reply_to:
        msg["In-Reply-To"] = in_reply_to
        # Build References chain: existing references + the message we're replying to
        if references:
            msg["References"] = f"{references} {in_reply_to}"
        else:
            msg["References"] = in_reply_to

    logger.info(
        f"Sending email reply: to={to_address}, from={from_address}, "
        f"subject='{subject[:50]}', body_len={len(reply_body)}"
    )

    try:
        ses_client = _get_ses_client()
        await asyncio.to_thread(
            ses_client.send_raw_email,
            Source=from_address,
            Destinations=[to_address],
            RawMessage={"Data": msg.as_string()},
        )
    except Exception as e:
        logger.error(f"SES send_raw_email failed: {e}")
        raise
