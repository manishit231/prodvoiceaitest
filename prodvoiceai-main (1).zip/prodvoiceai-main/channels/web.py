"""Web Chat channel adapter.

Handles WebSocket-based text chat for browser embedding.
Customers can chat through a widget on the barbershop's website.

Flow:
    Customer opens chat widget
    -> WebSocket connect to /ws/chat?tenant_id=t_001
    -> Each message: chat_service.process_message(tenant_id, session_id, text, "web_chat")
    -> WebSocket send: {"type": "response", "text": response}
"""

import json
import uuid

from fastapi import WebSocket, WebSocketDisconnect
from loguru import logger

import chat_service
import tenant_service


async def handle_chat_websocket(websocket: WebSocket, tenant_id: str):
    """Handle a WebSocket chat connection for a specific tenant.

    Args:
        websocket: FastAPI WebSocket connection
        tenant_id: The tenant ID from query parameter
    """
    await websocket.accept()

    # Generate a unique session ID for this browser session
    session_id = f"web_{uuid.uuid4().hex[:12]}"

    # Load tenant config to validate
    config = await tenant_service.load_tenant_config(tenant_id)
    if not config:
        await websocket.send_json({
            "type": "error",
            "text": "Sorry, this business is not configured. Please try again later.",
        })
        await websocket.close()
        return

    # Check if web_chat is enabled
    if "web_chat" not in config.enabled_channels:
        await websocket.send_json({
            "type": "error",
            "text": f"Web chat is not currently enabled for {config.business_name}.",
        })
        await websocket.close()
        return

    logger.info(
        f"[{tenant_id}] Web chat connected: session={session_id}, "
        f"business={config.business_name}"
    )

    # Send welcome message
    await websocket.send_json({
        "type": "welcome",
        "text": (
            f"Hi! Welcome to {config.business_name}. "
            f"I can help you book, cancel, or check appointments. "
            f"How can I help you today?"
        ),
        "business_name": config.business_name,
        "session_id": session_id,
    })

    try:
        while True:
            # Receive message from client
            data = await websocket.receive_text()

            try:
                msg = json.loads(data)
                user_text = msg.get("text", "").strip()
            except json.JSONDecodeError:
                # Plain text message
                user_text = data.strip()

            if not user_text:
                continue

            logger.info(f"[{tenant_id}] Web chat [{session_id}]: '{user_text[:50]}'")

            # Send typing indicator
            await websocket.send_json({"type": "typing", "status": True})

            # Process through shared chat engine
            response_text = await chat_service.process_message(
                tenant_id=tenant_id,
                session_id=session_id,
                user_message=user_text,
                channel="web_chat",
            )

            # Send response
            await websocket.send_json({
                "type": "response",
                "text": response_text,
            })

    except WebSocketDisconnect:
        logger.info(f"[{tenant_id}] Web chat disconnected: session={session_id}")
    except Exception as e:
        logger.error(f"[{tenant_id}] Web chat error: {e}")
        try:
            await websocket.send_json({
                "type": "error",
                "text": "Sorry, something went wrong. Please try again.",
            })
            await websocket.close()
        except Exception:
            pass
