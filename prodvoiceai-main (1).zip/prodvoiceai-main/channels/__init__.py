"""Channel adapters for multi-channel booking.

Each channel adapter normalizes incoming messages and routes them
through the shared chat_service.process_message() engine.

Available channels:
    sms.py   — Twilio SMS webhook adapter
    web.py   — WebSocket chat adapter for browser widget
    email.py — AWS SES/SNS inbound email adapter
"""
