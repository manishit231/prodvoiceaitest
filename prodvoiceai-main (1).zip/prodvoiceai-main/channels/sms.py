"""Twilio SMS channel adapter.

Handles incoming SMS messages via Twilio webhook and routes them
through the shared chat_service for appointment booking.

Twilio Flow:
    Customer texts +14255347267
    -> Twilio POST /webhooks/sms {From, To, Body}
    -> Look up tenant by To number
    -> chat_service.process_message(tenant_id, from_phone, body, "sms")
    -> Return TwiML <Message>{response}</Message>
"""

from fastapi import Request
from fastapi.responses import Response
from loguru import logger

import chat_service
import tenant_service


def _normalize_phone(number: str) -> str:
    """Normalize phone number — ensure it starts with + (Twilio format).

    URL-encoded form data can turn + into a space, so we fix that here.
    """
    number = number.strip()
    if number and not number.startswith("+"):
        number = "+" + number
    return number


async def handle_sms_webhook(request: Request) -> Response:
    """Handle incoming Twilio SMS webhook.

    Twilio sends a form-encoded POST with:
        From: sender's phone number (the customer)
        To: our Twilio number (maps to a tenant)
        Body: the text message content
    """
    form = await request.form()

    from_number = _normalize_phone(form.get("From", ""))
    to_number = _normalize_phone(form.get("To", ""))
    body = form.get("Body", "").strip()
    message_sid = form.get("MessageSid", "")

    logger.info(f"SMS received: From={from_number}, To={to_number}, Body='{body[:50]}', SID={message_sid}")

    if not body:
        return _twiml_response("Hi! How can I help you today? You can book, cancel, or check appointments.")

    # Look up tenant by the Twilio number that received the SMS
    tenant_id = await tenant_service.lookup_tenant_by_sms_phone(to_number)

    if not tenant_id:
        logger.error(f"No tenant found for SMS number: {to_number}")
        return _twiml_response("Sorry, this number is not configured for messaging.")

    # Check if SMS is enabled for this tenant
    config = await tenant_service.load_tenant_config(tenant_id)
    if config and "sms" not in config.enabled_channels:
        logger.warning(f"SMS not enabled for tenant {tenant_id}")
        return _twiml_response(
            f"SMS booking is not currently enabled for {config.business_name}. "
            f"Please call us instead."
        )

    # Process message through the shared chat engine
    # Use the customer's phone number as the session ID (natural for SMS)
    response_text = await chat_service.process_message(
        tenant_id=tenant_id,
        session_id=from_number,
        user_message=body,
        channel="sms",
        metadata={"from_number": from_number, "to_number": to_number},
    )

    return _twiml_response(response_text)


def _twiml_response(message: str) -> Response:
    """Build a TwiML response for SMS."""
    # Truncate if too long (SMS limit is 1600 chars for Twilio)
    if len(message) > 1500:
        message = message[:1497] + "..."

    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Message>{_escape_xml(message)}</Message>
</Response>"""

    return Response(content=xml, media_type="application/xml")


def _escape_xml(text: str) -> str:
    """Escape special XML characters."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )
